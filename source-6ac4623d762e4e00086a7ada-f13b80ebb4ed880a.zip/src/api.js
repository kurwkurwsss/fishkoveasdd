import { getUser, login, logout, signup } from "@netlify/identity";

export async function api(path, options = {}) {
  if (path === "/auth/login") {
    const identifier = options.body.email.trim();
    if (!identifier.includes("@"))
      return api("/auth/alias-login", { ...options, body: { email: identifier, password: options.body.password } });
    try {
      await login(identifier, options.body.password);
    } catch {
      throw new Error("Не удалось войти. Проверьте email или логин и пароль или подтвердите адрес почты.");
    }
    return api("/me");
  }
  if (path === "/auth/register") {
    let identity;
    try {
      identity = await signup(options.body.email, options.body.password, { full_name: options.body.name });
    } catch {
      throw new Error("Не удалось зарегистрироваться. Проверьте email и пароль; возможно, аккаунт уже существует.");
    }
    if (!identity.confirmedAt) return { confirmationRequired: true };
    return api("/me");
  }
  if (path === "/auth/logout") await logout();
  await getUser();
  const controller = new AbortController();
  const cancel = () => controller.abort();
  if (options.signal?.aborted) controller.abort();
  options.signal?.addEventListener("abort", cancel, { once: true });
  const timeout = setTimeout(cancel, 20000);
  try {
    const response = await fetch(`/api${path}`, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      ...options,
      signal: controller.signal,
      body: options.body === undefined
        ? options.method && options.method !== "GET" ? "{}" : undefined
        : JSON.stringify(options.body),
    });
    const data = await response.json().catch(() => ({ error: "Сервис временно недоступен. Повторите попытку." }));
    if (!response.ok) {
      const error = new Error(data.error || "Не удалось выполнить запрос.");
      error.status = response.status;
      throw error;
    }
    return data;
  } catch (error) {
    if (error.name === "AbortError" && !options.signal?.aborted)
      throw new Error("Сервер не ответил вовремя. Повторите попытку.");
    throw error;
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener("abort", cancel);
  }
}

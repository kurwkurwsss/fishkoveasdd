import React, { useEffect, useRef, useState, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight,
  ArrowRight,
  ArrowLeft,
  Search,
  Plus,
  Globe2,
  Users,
  Play,
  Film,
  Bookmark,
  Home,
  X,
  ChevronRight,
  ChevronDown,
  Link,
  Check,
  Sparkles,
  MonitorPlay,
  LogOut,
  Moon,
  Heart,
  Settings2,
  MessageCircle,
  Star,
  Clapperboard,
  Radio,
  Command,
  Menu,
  Palette,
  ShieldCheck,
  Crown,
} from "lucide-react";
import { api } from "./api";
import { getUser, handleAuthCallback, requestPasswordRecovery } from "@netlify/identity";
import { PasswordForm } from "./password";
import { Modal } from "./ui";
import {
  Avatar,
  UserName,
  ThemePicker,
  ProfilePanel,
  AdminPanel,
} from "./account";
import { AnimeDetail } from "./anime";
const Room = lazy(() => import("./room"));
import "./style.css";
const genres = [
  "Все аниме",
  "Популярное",
  "Фэнтези",
  "Романтика",
  "Приключения",
];
const genreQueries = {
  Популярное: "popular",
  Фэнтези: "fantasy",
  Романтика: "romance",
  Приключения: "adventure",
};
function App() {
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [page, setPage] = useState("home");
  const [anime, setAnime] = useState([]),
    [rooms, setRooms] = useState([]),
    [favorites, setFavorites] = useState([]);
  const [search, setSearch] = useState(""),
    [category, setCategory] = useState("Все аниме"),
    [catalogLoading, setCatalogLoading] = useState(true),
    [catalogError, setCatalogError] = useState(""),
    [cached, setCached] = useState(false);
  const [modal, setModal] = useState(null),
    [detail, setDetail] = useState(null),
    [toast, setToast] = useState(""),
    [roomId, setRoomId] = useState(
      new URLSearchParams(location.search).get("room"),
    ),
    [menu, setMenu] = useState(false);
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem("yoru-theme") || "midnight";
    } catch {
      return "midnight";
    }
  });
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem("yoru-theme", theme);
    } catch {}
  }, [theme]);
  useEffect(() => {
    if (user?.theme) setTheme(user.theme);
  }, [user?.theme]);
  async function changeTheme(value) {
    try {
      if (user)
        setUser(
          (await api("/profile", { method: "PATCH", body: { theme: value } }))
            .user,
        );
      setTheme(value);
    } catch (e) {
      notify(e.message);
    }
  }
  const searchRef = useRef();
  const notify = (message) => setToast(message);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 5000);
    return () => clearTimeout(timer);
  }, [toast]);
  const refreshUserData = () =>
    Promise.all([api("/rooms"), api("/favorites")])
      .then(([r, f]) => {
        setRooms(r.rooms);
        setFavorites(f.items);
      })
      .catch((e) => notify(e.message));
  useEffect(() => {
    async function initialize() {
      const callback = await handleAuthCallback();
      if (callback?.type === "invite" || callback?.type === "recovery") {
        setModal({ type: "password", callback });
      } else if (callback) notify("Email подтверждён. Добро пожаловать в Yoru!");
      await getUser();
      return api("/me");
    }
    initialize()
      .then(({ user }) => setUser(user))
      .catch((e) => notify(e.message))
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    if (user) refreshUserData();
    else {
      setRooms([]);
      setFavorites([]);
    }
  }, [user]);
  useEffect(() => {
    let cancelled = false;
    setCatalogLoading(true);
    const timer = setTimeout(
      () =>
        api(
          `/catalog?q=${encodeURIComponent(search)}&genre=${genreQueries[category] || ""}`,
        )
          .then((data) => {
            if (!cancelled) {
              setAnime(data.items);
              setCached(data.cached);
              setCatalogError("");
            }
          })
          .catch((e) => {
            if (!cancelled) {
              setCatalogError(e.message);
              setAnime([]);
            }
          })
          .finally(() => {
            if (!cancelled) setCatalogLoading(false);
          }),
      search ? 350 : 0,
    );
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [search, category]);
  useEffect(() => {
    const pop = () =>
      setRoomId(new URLSearchParams(location.search).get("room"));
    addEventListener("popstate", pop);
    return () => removeEventListener("popstate", pop);
  }, []);
  const enterRoom = (id) => {
    history.pushState({}, "", `?room=${encodeURIComponent(id)}`);
    setRoomId(id);
    setModal(null);
    setDetail(null);
  };
  const leaveRoom = () => {
    history.pushState({}, "", "/");
    setRoomId(null);
    refreshUserData();
  };
  const requireUser = (action) => {
    if (!user) {
      setModal({ type: "auth", next: action });
      return;
    }
    action();
  };
  const createRoom = () => requireUser(() => setModal({ type: "create" }));
  const toggleFavorite = async (item) => {
    if (!user) {
      setModal({ type: "auth" });
      return;
    }
    try {
      if (favorites.some((f) => f.id === item.id)) {
        await api(`/favorites/${item.id}`, { method: "DELETE" });
        setFavorites((f) => f.filter((a) => a.id !== item.id));
      } else {
        await api("/favorites", { method: "POST", body: { anime: item } });
        setFavorites((f) => [...f, item]);
      }
    } catch (e) {
      notify(e.message);
    }
  };
  if (loading)
    return (
      <div className="boot">
        <Logo />
        <span>Собираем уютную компанию…</span>
      </div>
    );
  const hero =
    anime.find((a) => a.id === "7442") || anime.find((a) => a.cover) || null;
  return (
    <>
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <a
          className="brand"
          href="/"
          onClick={(e) => {
            e.preventDefault();
            leaveRoom();
            setPage("home");
          }}
        >
          <Logo />
          <span>
            yoru<span className="brand-dot">.</span>
          </span>
        </a>
        <span className="nav-caption">ВАШЕ ПРОСТРАНСТВО</span>
        <nav>
          {[
            [Home, "home", "Главная"],
            [Clapperboard, "catalog", "Каталог аниме"],
            [Users, "rooms", "Мои комнаты"],
            [Bookmark, "saved", "Смотреть позже"],
            ...(user?.role === "admin"
              ? [[ShieldCheck, "admin", "Админка"]]
              : []),
          ].map(([Icon, key, label]) => (
            <button
              key={key}
              className={
                page === key && !roomId ? "nav-item active" : "nav-item"
              }
              onClick={() => {
                if (roomId) leaveRoom();
                setPage(key);
                setMenu(false);
              }}
            >
              <Icon size={19} />
              <span>{label}</span>
              {key === "saved" && favorites.length > 0 && (
                <small>{favorites.length}</small>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-room">
          <span className="nav-caption">ВМЕСТЕ ИНТЕРЕСНЕЕ</span>
          <button className="nav-item" onClick={createRoom}>
            <Plus size={19} />
            Создать комнату
          </button>
          <button
            className="nav-item"
            onClick={() => requireUser(() => setModal({ type: "join" }))}
          >
            <Link size={19} />
            По приглашению
          </button>
        </div>
        <button
          className="nav-item"
          onClick={() => {
            setModal({ type: "settings" });
            setMenu(false);
          }}
        >
          <Palette size={19} />
          Оформление и профиль
        </button>
        <div className="sidebar-bottom">
          <div className="orbit-card">
            <div className="orbit">
              <Moon size={24} />
              <i />
              <i />
            </div>
            <strong>Ближе, даже издалека</strong>
            <p>
              Ваши истории. Ваши люди.
              <br />
              Один общий экран.
            </p>
            <button onClick={createRoom}>
              Собраться вместе <ArrowUpRight size={15} />
            </button>
          </div>
          <div className="sidebar-footer">
            <span className="status-dot" />
            Время хороших историй
            <Moon size={14} />
          </div>
        </div>
      </aside>
      <div className="shell">
        <header className="topbar">
          <button
            className="icon-button mobile-menu"
            aria-label="Открыть меню"
            onClick={() => setMenu(!menu)}
          >
            <Menu size={22} />
          </button>
          <div className="breadcrumbs">
            Ваше пространство <ChevronRight size={14} />
            <span>
              {roomId
                ? "Комната"
                : {
                    home: "Главная",
                    catalog: "Каталог аниме",
                    rooms: "Мои комнаты",
                    saved: "Смотреть позже",
                    admin: "Админка",
                  }[page]}
            </span>
          </div>
          <div className="top-search">
            <Search size={17} />
            <input
              ref={searchRef}
              placeholder="Найти аниме…"
              aria-label="Найти аниме"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                if (roomId) leaveRoom();
                setPage("catalog");
              }}
            />
            <span>⌕</span>
          </div>
          <div className="top-separator" />
          {user ? (
            <button
              className="profile"
              onClick={() => setModal({ type: "profile" })}
            >
              <Avatar user={user} />
              <UserName user={user} />
              <ChevronDown size={13} />
            </button>
          ) : (
            <button
              className="login-button"
              onClick={() => setModal({ type: "auth" })}
            >
              Войти <ArrowUpRight size={15} />
            </button>
          )}
        </header>
        {roomId ? (
          user ? (
            <Suspense
              fallback={<div className="invite-gate">Загружаем комнату…</div>}
            >
              <Room
                id={roomId}
                user={user}
                onBlocked={(message) => {
                  setUser(null);
                  setRoomId(null);
                  history.replaceState({}, "", "/");
                  notify(message || "Войдите снова, чтобы продолжить.");
                }}
                notify={notify}
                onLeave={leaveRoom}
              />
            </Suspense>
          ) : (
            <div className="invite-gate">
              <div className="large-icon">
                <Users />
              </div>
              <span className="eyebrow">ВАС ПРИГЛАСИЛИ</span>
              <h1>Вместе — лучше.</h1>
              <p>Представьтесь, чтобы присоединиться к просмотру.</p>
              <button
                className="primary"
                onClick={() => setModal({ type: "auth" })}
              >
                Войти в комнату <ArrowRight size={17} />
              </button>
            </div>
          )
        ) : page === "admin" && user?.role === "admin" ? (
          <AdminPanel notify={notify} />
        ) : (
          <main className="dashboard">
            {page === "home" && (
              <>
                <div className="page-heading">
                  <div>
                    <span className="eyebrow">ВАШ СЛЕДУЮЩИЙ ХОРОШИЙ ВЕЧЕР</span>
                    <h1>
                      Что посмотрим сегодня<span className="accent">?</span>
                    </h1>
                    <p>Выбирайте историю, зовите друзей. Остальное — здесь.</p>
                  </div>
                  <div className="date-badge">
                    <span className="status-dot" />
                    Место встречи — yoru
                  </div>
                </div>
                <section
                  className="hero"
                  style={
                    hero?.cover
                      ? { "--hero-image": `url("${hero.cover}")` }
                      : {}
                  }
                >
                  <div className="hero-grain" />
                  <div className="hero-content">
                    <span className="hero-label">
                      <Sparkles size={13} /> РАЗДЕЛИТЕ ВПЕЧАТЛЕНИЯ
                    </span>
                    <h2>
                      На одной волне.
                      <br />
                      На одном экране.
                    </h2>
                    <p>
                      Кино, аниме и ваша компания.
                      <br />
                      Смотрите вместе, где бы вы ни были.
                    </p>
                    <button className="primary" onClick={createRoom}>
                      <Plus size={18} />
                      Создать комнату
                      <ArrowUpRight size={17} />
                    </button>
                    <div className="hero-note">
                      <span className="mini-avatars">
                        <i>Ю</i>
                        <i>М</i>
                        <i>А</i>
                      </span>
                      <span>Для вас и вашей компании</span>
                    </div>
                  </div>
                  <div className="hero-caption">
                    <span className="tiny-pill">В КАТАЛОГЕ</span>
                    <strong>{hero?.title || "Ваша следующая история"}</strong>
                    <span>
                      Найдите то, что захочется обсудить{" "}
                      <ArrowUpRight size={14} />
                    </span>
                  </div>
                  <div className="hero-index">
                    <span />
                    01 <i>/</i> ВАШ ВЕЧЕР
                  </div>
                </section>
                <section className="quick-actions">
                  <button className="quick-card" onClick={createRoom}>
                    <span className="quick-icon lavender">
                      <Globe2 size={23} />
                    </span>
                    <span>
                      <strong>Один вечер на всех</strong>
                      <small>Видео, чат и друзья в одной комнате</small>
                    </span>
                    <ArrowUpRight size={20} />
                  </button>
                  <button
                    className="quick-card"
                    onClick={() =>
                      requireUser(() => setModal({ type: "join" }))
                    }
                  >
                    <span className="quick-icon peach">
                      <Link size={22} />
                    </span>
                    <span>
                      <strong>Вас уже ждут?</strong>
                      <small>Присоединяйтесь по ссылке в комнату</small>
                    </span>
                    <ArrowUpRight size={20} />
                  </button>
                </section>
              </>
            )}
            {page === "rooms" ? (
              <>
                <SectionTitle eyebrow="ВАША КОМПАНИЯ" title="Мои комнаты" />
                <div className="rooms-grid">
                  {rooms.map((room) => (
                    <button
                      key={room.id}
                      className="room-card"
                      onClick={() => enterRoom(room.id)}
                    >
                      <div className="room-card-art">
                        <MonitorPlay size={36} />
                        <span>
                          <span className="status-dot" />
                          {room.online} в сети
                        </span>
                      </div>
                      <strong>{room.name}</strong>
                      <p>
                        Приватная комната <ArrowUpRight size={17} />
                      </p>
                    </button>
                  ))}
                  <button className="new-room-card" onClick={createRoom}>
                    <Plus />
                    <strong>Новая история начинается здесь</strong>
                    <span>Создать комнату</span>
                  </button>
                </div>
              </>
            ) : (
              <section className="catalog-section">
                <SectionTitle
                  eyebrow={
                    page === "home"
                      ? "ЕЩЁ ОДНУ СЕРИЮ?"
                      : page === "saved"
                        ? "ВАША КОЛЛЕКЦИЯ"
                        : "НАЙДИТЕ СВОЮ ИСТОРИЮ"
                  }
                  title={
                    page === "saved"
                      ? "Смотреть позже"
                      : search
                        ? `Поиск: ${search}`
                        : page === "home"
                          ? "В центре внимания"
                          : "Каталог аниме"
                  }
                  action={page === "home" ? () => setPage("catalog") : null}
                />
                {page !== "saved" && (
                  <div className="catalog-toolbar">
                    <div className="filter-tabs">
                      {genres.map((g) => (
                        <button
                          key={g}
                          className={g === category ? "selected" : ""}
                          onClick={() => {
                            setCategory(g);
                            setSearch("");
                          }}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                    <span className="catalog-source">
                      {cached ? "Сохранённый каталог" : "Каталог AniLibria"}{" "}
                      <span className="status-dot" />
                    </span>
                  </div>
                )}
                {catalogError && page !== "saved" && (
                  <div className="inline-error">
                    {catalogError}
                    <button
                      onClick={() => {
                        setCategory("Все аниме");
                        setSearch("");
                      }}
                    >
                      Показать популярное
                    </button>
                  </div>
                )}
                <div className="anime-grid">
                  {catalogLoading && page !== "saved"
                    ? Array.from({ length: 6 }, (_, i) => (
                        <div className="anime-skeleton" key={i} />
                      ))
                    : (page === "saved"
                        ? favorites
                        : anime.slice(0, page === "home" ? 6 : 20)
                      ).map((item, index) => (
                        <article className="anime-card" key={item.id}>
                          <button
                            className="poster-button"
                            onClick={() => setDetail(item)}
                            aria-label={`Открыть ${item.title}`}
                          >
                            <img
                              src={item.poster}
                              alt={item.title}
                              loading="lazy"
                            />
                            <span className="score">
                              <Star size={11} fill="currentColor" />
                              {item.score || "—"}
                            </span>
                            <span className="poster-play">
                              <Play fill="currentColor" size={22} />
                            </span>
                            <span className="poster-bottom">
                              {item.type || "TV"}
                              <span>
                                {item.episodes
                                  ? `${item.episodes} эп.`
                                  : "Онгоинг"}
                              </span>
                            </span>
                          </button>
                          <button
                            className={`save-button ${favorites.some((a) => a.id === item.id) ? "saved" : ""}`}
                            aria-label={`Сохранить ${item.title}`}
                            onClick={() => toggleFavorite(item)}
                          >
                            <Bookmark
                              size={15}
                              fill={
                                favorites.some((a) => a.id === item.id)
                                  ? "currentColor"
                                  : "none"
                              }
                            />
                          </button>
                          <h3>
                            <button onClick={() => setDetail(item)}>
                              {item.title}
                            </button>
                          </h3>
                          <p>
                            {item.year || "—"}
                            <i />{" "}
                            {item.status === "current"
                              ? "Выходит"
                              : item.status === "finished"
                                ? "Завершён"
                                : "Аниме"}
                          </p>
                        </article>
                      ))}
                </div>
                {!catalogLoading &&
                  !(page === "saved" ? favorites : anime).length &&
                  !catalogError && (
                    <div className="empty-state">
                      <Bookmark size={30} />
                      <h3>
                        {page === "saved"
                          ? "Ваш список только начинается"
                          : "Ничего не найдено"}
                      </h3>
                      <p>
                        {page === "saved"
                          ? "Сохраняйте аниме, к которому хочется вернуться."
                          : "Попробуйте название на английском или японском."}
                      </p>
                    </div>
                  )}
                {page === "home" && (
                  <div className="bottom-banner">
                    <div>
                      <span className="little-stars">✳</span>
                      <p>
                        <strong>
                          Хорошая история становится лучше, когда есть с кем
                          поделиться.
                        </strong>
                        <span>
                          Создайте свою комнату — пригласить друзей можно одной
                          ссылкой.
                        </span>
                      </p>
                    </div>
                    <button onClick={createRoom}>
                      Начать свой вечер <ArrowRight size={16} />
                    </button>
                  </div>
                )}
              </section>
            )}
            <footer className="page-footer">
              <span>
                yoru. <i>Маленькое расстояние между вами.</i>
              </span>
              <span>
                Сделано для совместных вечеров <Moon size={13} />
              </span>
            </footer>
          </main>
        )}
      </div>
      {toast && (
        <div className="toast" role="status">
          <span>{toast}</span>
          <button aria-label="Закрыть уведомление" onClick={() => setToast("")}>
            <X size={16} />
          </button>
        </div>
      )}
      {modal && (
        <Modal
          close={() => setModal(null)}
          wide={["profile", "settings"].includes(modal.type)}
        >
          {modal.type === "auth" ? (
            <Auth
              initialMode={modal.initialMode}
              onSuccess={(u) => {
                setUser(u);
                setModal(null);
                if (modal.next) modal.next();
              }}
            />
          ) : modal.type === "password" ? (
            <PasswordForm callback={modal.callback} onSuccess={(updated) => {
              setUser(updated);
              setModal(null);
              notify("Пароль сохранён.");
            }} />
          ) : modal.type === "create" ? (
            <CreateRoom onCreated={enterRoom} anime={modal.anime} />
          ) : modal.type === "join" ? (
            <JoinRoom onJoin={enterRoom} />
          ) : user ? (
            <ProfilePanel
              user={user}
              onUser={setUser}
              theme={theme}
              onTheme={changeTheme}
              onRegister={() =>
                setModal({ type: "auth", initialMode: "register" })
              }
              onLogout={async () => {
                try {
                  await api("/auth/logout", { method: "POST" });
                  setUser(null);
                  setModal(null);
                  setRoomId(null);
                  setPage("home");
                  history.replaceState({}, "", "/");
                } catch (e) {
                  notify(e.message);
                }
              }}
            />
          ) : (
            <div className="account-panel">
              <span className="eyebrow">ВАШЕ НАСТРОЕНИЕ</span>
              <h2>Выберите стиль сайта</h2>
              <ThemePicker value={theme} onChange={changeTheme} />
              <p className="muted">
                Для аватарки и бесплатного Yoru Plus достаточно имени —
                регистрация не обязательна.
              </p>
              <button
                className="primary"
                onClick={() => setModal({ type: "auth" })}
              >
                Создать гостевой профиль
              </button>
            </div>
          )}
        </Modal>
      )}
      {detail && (
        <Modal close={() => setDetail(null)} wide>
          <AnimeDetail
            key={detail.id}
            anime={detail}
            saved={favorites.some((f) => f.id === detail.id)}
            onFavorite={() => toggleFavorite(detail)}
            onWatch={(anime) => {
              setDetail(null);
              requireUser(() => setModal({ type: "create", anime }));
            }}
          />
        </Modal>
      )}
    </>
  );
}
function Logo() {
  return (
    <svg
      width="32"
      height="35"
      viewBox="0 0 32 35"
      fill="none"
      aria-hidden="true"
    >
      <path d="M3 4L16 14L29 4V22L16 33L3 22V4Z" fill="currentColor" />
      <path d="M16 14V33" stroke="#141518" strokeWidth="3" />
    </svg>
  );
}
function SectionTitle({ eyebrow, title, action }) {
  return (
    <div className="section-heading">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      {action && (
        <button onClick={action}>
          Весь каталог <ArrowRight size={16} />
        </button>
      )}
    </div>
  );
}

function Auth({ onSuccess, initialMode = "guest" }) {
  const [mode, setMode] = useState(initialMode),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError("");
        setNotice("");
        const data = Object.fromEntries(new FormData(e.currentTarget));
        try {
          const result = await api(`/auth/${mode}`, { method: "POST", body: data });
          if (result.confirmationRequired) setNotice("Письмо отправлено. Подтвердите email по ссылке в письме, чтобы сохранить профиль.");
          else if (result.reload) window.location.reload();
          else if (result.user) onSuccess(result.user);
          else throw new Error("Не удалось восстановить сеанс. Повторите вход.");
        } catch (e) {
          setError(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <div className="modal-symbol">
        <Moon size={28} />
      </div>
      <span className="eyebrow">ДОБРО ПОЖАЛОВАТЬ В YORU</span>
      <h2>Ваша компания ближе.</h2>
      <p className="muted">Представьтесь — и можно начинать вечер.</p>
      <div className="segmented">
        {[
          ["guest", "Быстрый вход"],
          ["login", "Войти"],
          ["register", "Регистрация"],
        ].map(([key, title]) => (
          <button
            type="button"
            key={key}
            className={mode === key ? "selected" : ""}
            onClick={() => {
              setMode(key);
              setError("");
              setNotice("");
            }}
          >
            {title}
          </button>
        ))}
      </div>
      {mode !== "login" && (
        <label>
          Как вас зовут
          <input
            name="name"
            placeholder="Ваше имя"
            minLength={2}
            maxLength={40}
            required
            autoComplete="nickname"
          />
        </label>
      )}
      {mode !== "guest" && (
        <>
          <label>
            {mode === "login" ? "Email или логин" : "Email"}
            <input
              name="email"
              type={mode === "login" ? "text" : "email"}
              placeholder={mode === "login" ? "Ваш email или логин" : "Ваш email"}
              required
              autoComplete={mode === "login" ? "username" : "email"}
            />
          </label>
          <label>
            Пароль
            <input
              name="password"
              type="password"
              minLength={mode === "register" ? 10 : 1}
              maxLength={128}
              placeholder="Не менее 10 символов"
              required
              autoComplete={
                mode === "login" ? "current-password" : "new-password"
              }
            />
          </label>
        </>
      )}
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {notice && <p className="save-status" role="status">{notice}</p>}
      <button disabled={busy} className="primary full">
        {busy
          ? "Подождите…"
          : mode === "guest"
            ? "Начать вечер"
            : mode === "login"
              ? "Войти"
              : "Создать аккаунт"}
        <ArrowRight size={17} />
      </button>
      <p className="form-hint">
        {mode === "guest"
          ? "Без пароля. Позже можно сохранить профиль, добавив email."
          : "Ваши комнаты и коллекция будут доступны с любого устройства."}
      </p>
      {mode === "login" && <button className="secondary full" type="button" disabled={busy} onClick={async (event) => {
        const email = event.currentTarget.form.elements.email.value;
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) { setError("Введите email для восстановления пароля, а не логин."); return; }
        setBusy(true);
        setError("");
        try {
          await requestPasswordRecovery(email);
          setNotice("Если аккаунт существует, на почту придёт ссылка для восстановления.");
        } catch { setError("Не удалось отправить письмо. Попробуйте позже."); }
        finally { setBusy(false); }
      }}>Забыли пароль?</button>}
    </form>
  );
}
function CreateRoom({ onCreated, anime }) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        try {
          const { room } = await api("/rooms", {
            method: "POST",
            body: {
              name: new FormData(e.currentTarget).get("name"),
              ...(anime ? { anime } : {}),
            },
          });
          onCreated(room.id);
        } catch (e) {
          setError(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <div className="modal-symbol">
        <MonitorPlay size={28} />
      </div>
      <span className="eyebrow">ОДИН ЭКРАН. ВАША КОМПАНИЯ.</span>
      <h2>Устроим хороший вечер?</h2>
      <p className="muted">
        Комната приватная. Войти смогут те, кому вы отправите приглашение.
      </p>
      <label>
        Название комнаты
        <input
          name="name"
          required
          defaultValue={anime ? anime.title.slice(0, 40) : "Наш уютный вечер"}
          maxLength={40}
        />
      </label>
      {anime && (
        <p className="source-note">
          {anime.title} · {anime.episode} серия · AniLibria
        </p>
      )}
      <div className="creation-features">
        <span>
          <Users size={16} />
          Приватная комната
        </span>
        <span>
          <MessageCircle size={16} />
          Живой чат
        </span>
        <span>
          <Film size={16} />
          Синхронный плеер
        </span>
      </div>
      {error && <p className="form-error">{error}</p>}
      <button className="primary full" disabled={busy}>
        {busy ? "Создаём…" : "Создать комнату"}
        <ArrowRight size={17} />
      </button>
    </form>
  );
}
function JoinRoom({ onJoin }) {
  const [error, setError] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const value = new FormData(e.currentTarget).get("invite").trim();
        let id = value;
        try {
          if (value.includes("://"))
            id = new URL(value).searchParams.get("room");
          if (!id || !/^[A-Za-z0-9_-]{16}$/.test(id)) throw Error();
          onJoin(id);
        } catch {
          setError("Вставьте ссылку приглашения или код комнаты.");
        }
      }}
    >
      <div className="modal-symbol">
        <Link size={28} />
      </div>
      <h2>Вас уже ждут</h2>
      <p className="muted">Вставьте приглашение от друга.</p>
      <label>
        Ссылка или код комнаты
        <input name="invite" placeholder="https://…/?room=…" required />
      </label>
      {error && <p className="form-error">{error}</p>}
      <button className="primary full">
        Присоединиться
        <ArrowRight size={17} />
      </button>
    </form>
  );
}
createRoot(document.getElementById("root")).render(<App />);

import React, { useState } from "react";
import { acceptInvite, updateUser } from "@netlify/identity";
import { api } from "./api";

export function PasswordForm({ callback, onSuccess }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  return <form onSubmit={async (event) => {
    event.preventDefault();
    const password = new FormData(event.currentTarget).get("password");
    setBusy(true);
    setError("");
    try {
      if (callback.type === "invite") await acceptInvite(callback.token, password);
      else await updateUser({ password });
      const { user } = await api("/me");
      if (!user) throw new Error();
      onSuccess(user);
    } catch { setError("Не удалось сохранить пароль. Попробуйте новую ссылку из письма."); }
    finally { setBusy(false); }
  }}>
    <span className="eyebrow">ВАШ АККАУНТ YORU</span>
    <h2>Задайте новый пароль</h2>
    <label>Пароль<input name="password" type="password" minLength={10} maxLength={128} autoComplete="new-password" required /></label>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="primary full" disabled={busy}>{busy ? "Сохраняем…" : "Сохранить пароль"}</button>
  </form>;
}

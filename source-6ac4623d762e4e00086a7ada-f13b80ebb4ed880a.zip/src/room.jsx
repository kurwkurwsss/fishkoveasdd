import React, { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import {
  ArrowLeft,
  ArrowRight,
  MonitorPlay,
  Users,
  MessageCircle,
  Check,
  Send,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  RotateCw,
  ChevronLeft,
  Plus,
  Link,
  Film,
  MousePointer2,
  ChevronDown,
  LoaderCircle,
  Wifi,
  WifiOff,
  Settings2,
  Trash2,
} from "lucide-react";
import { api } from "./api";
import { Modal } from "./ui";
import { Avatar, UserName } from "./account";
import { AnimeLibrary } from "./anime";
export default function Room({ id, user, notify, onLeave, onBlocked }) {
  const [room, setRoom] = useState(null),
    [users, setUsers] = useState([]),
    [messages, setMessages] = useState([]),
    [connected, setConnected] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [modal, setModal] = useState(false),
    [copied, setCopied] = useState(false),
    [tab, setTab] = useState("chat"),
    [library, setLibrary] = useState([]);
  const [cinema, setCinema] = useState(false);
  const [mobile, setMobile] = useState(
    () =>
      matchMedia(
        "(max-width: 700px), (max-height: 500px) and (pointer: coarse)",
      ).matches,
  );
  const pageRef = useRef();
  useEffect(() => {
    const query = matchMedia(
      "(max-width: 700px), (max-height: 500px) and (pointer: coarse)",
    );
    const update = () => setMobile(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    if (!mobile || !room) return;
    const viewport = window.visualViewport;
    const update = () => {
      const page = pageRef.current;
      if (!page) return;
      page.toggleAttribute(
        "data-keyboard",
        (viewport?.height || window.innerHeight) < window.innerHeight - 120,
      );
      page.style.setProperty(
        "--room-height",
        `${viewport?.height || window.innerHeight}px`,
      );
      page.style.setProperty("--room-top", `${viewport?.offsetTop || 0}px`);
    };
    update();
    viewport?.addEventListener("resize", update);
    viewport?.addEventListener("scroll", update);
    window.addEventListener("resize", update);
    return () => {
      viewport?.removeEventListener("resize", update);
      viewport?.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, [mobile, Boolean(room)]);
  const bottomRef = useRef(),
    clockOffset = useRef(0),
    mutationVersion = useRef(0),
    mounted = useRef(false);
  const applySnapshot = (data) => {
    if (!mounted.current) return;
    setRoom(data.room);
    setUsers(data.users);
    setMessages(data.messages);
    clockOffset.current = data.serverTime - Date.now();
    setConnected(true);
    setError("");
  };
  useEffect(() => {
    let disposed = false;
    let timer;
    const controller = new AbortController();
    mounted.current = true;
    setRoom(null);
    setError("");
    setConnected(false);
    const handleError = (error) => {
      if (disposed || error.name === "AbortError") return;
      setConnected(false);
      setError(error.message);
      if (error.status === 401 || error.status === 403) onBlocked?.(error.message);
      if (error.status === 404) { notify(error.message); onLeave(); }
    };
    async function poll() {
      const version = mutationVersion.current;
      try {
        const data = await api(`/rooms/${id}`, { signal: controller.signal });
        if (!disposed && version === mutationVersion.current) applySnapshot(data);
      } catch (error) { handleError(error); }
      finally {
        if (!disposed) timer = setTimeout(poll, document.hidden ? 15000 : 2000);
      }
    }
    async function join() {
      try {
        const data = await api(`/rooms/${id}/join`, { method: "POST", signal: controller.signal });
        if (disposed) return;
        applySnapshot(data);
        timer = setTimeout(poll, 2000);
      } catch (error) { handleError(error); }
    }
    join();
    api("/library", { signal: controller.signal }).then((data) => {
      if (!disposed) setLibrary(data.series);
    }).catch((error) => {
      if (!disposed && error.name !== "AbortError") notify(error.message);
    });
    return () => {
      disposed = true;
      mounted.current = false;
      clearTimeout(timer);
      controller.abort();
      api(`/rooms/${id}/leave`, { method: "POST", keepalive: true }).catch(() => {});
    };
  }, [id, user.id]);
  useEffect(() => {
    // Scroll only the message list, never the page or the video out of view.
    const list = bottomRef.current?.parentElement;
    list?.scrollTo({ top: list.scrollHeight, behavior: "smooth" });
  }, [messages.at(-1)?.id, tab]);
  const control = room?.controller === user.id;
  const call = async (event, payload = {}) => {
    const version = ++mutationVersion.current;
    try {
      const data = await api(`/rooms/${id}/action`, { method: "POST", body: { event, payload } });
      if (version === mutationVersion.current) applySnapshot(data);
      return data;
    } catch (error) {
      notify(error.message);
      throw error;
    }
  };
  const action = async (event, payload) => {
    setBusy(true);
    try {
      await call(event, payload);
    } catch {
    } finally {
      setBusy(false);
    }
  };
  if (error && !room)
    return (
      <div className="invite-gate">
        <WifiOff size={32} />
        <h2>Не удалось войти</h2>
        <p>{error}</p>
        <button className="primary" onClick={() => location.reload()}>
          Повторить подключение
        </button>
        <button className="secondary" onClick={onLeave}>
          На главную
        </button>
      </div>
    );
  if (!room)
    return (
      <div className="invite-gate">
        <LoaderCircle className="spin" />
        <p>Готовим вашу комнату…</p>
      </div>
    );
  const activeController = users.find((u) => u.id === room.controller);
  const roomLibrary = (
      <section className="episode-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">СЛЕДУЮЩАЯ ИСТОРИЯ</span>
            <h2>Видео и серии</h2>
          </div>
          <button disabled={!control} onClick={() => setModal("media")}>
            <Plus size={16} />
            Добавить видео
          </button>
        </div>
        <AnimeLibrary
          releaseId={room.state.media?.releaseId}
          media={room.state.media}
          disabled={!control || busy || !connected}
          onSelect={(selection) => action("anime:select", selection)}
        />
        {library.map((series) => (
          <div className="series" key={series.id}>
            <div>
              <strong>{series.title}</strong>
              <p>{series.description}</p>
            </div>
            <div className="episode-buttons">
              {series.episodes.map((episode) => (
                <button
                  key={episode.episode}
                  disabled={!control}
                  className={
                    room.state.media?.episode === episode.episode &&
                    room.state.media?.title === series.title
                      ? "selected"
                      : ""
                  }
                  onClick={() =>
                    action("media:select", {
                      media: { ...episode, title: series.title },
                    })
                  }
                >
                  <Play size={12} />
                  {episode.episode} серия
                </button>
              ))}
            </div>
          </div>
        ))}
      </section>
  );
  return (
    <main
      ref={pageRef}
      className={`room-page ${cinema && user.premium ? "cinema" : ""}`}
    >
      <div className="room-heading">
        <div>
          <button className="back-link" onClick={onLeave}>
            <ArrowLeft size={14} />
            Моё пространство
          </button>
          <h1>
            {room.name}
            <span className="room-private">ПРИВАТНАЯ</span>
          </h1>
        </div>
        <button
          className="secondary"
          aria-label="Пригласить друзей"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(location.href);
              setCopied(true);
              setTimeout(() => setCopied(false), 2500);
            } catch {
              setModal("invite");
            }
          }}
        >
          {copied ? <Check size={16} /> : <Link size={16} />}
          <span>{copied ? "Ссылка скопирована" : "Пригласить друзей"}</span>
        </button>
        {room.owner === user.id && <button className="secondary" aria-label="Удалить комнату" disabled={busy} onClick={() => setModal("delete")}>
          <Trash2 size={16} /> <span>Удалить комнату</span>
        </button>}
      </div>
      <div className="room-layout">
        <div className="watch-column">
          {user.premium && (
            <button
              className="cinema-toggle secondary"
              onClick={() => setCinema((v) => !v)}
              aria-pressed={cinema}
            >
              <Maximize size={15} />
              {cinema ? "Выйти из кинотеатра" : "Режим кинотеатра"}
            </button>
          )}
          <div className="watch-toolbar">
            <div className="mode-tabs">
              <button
                className={room.state.mode === "video" ? "active" : ""}
                disabled
              >
                <Film size={16} />
                Видеоплеер
              </button>
            </div>
            <span className={`connection ${connected ? "" : "offline"}`}>
              {connected ? <Wifi size={14} /> : <WifiOff size={14} />}
              <span title={error || "Обновление комнаты каждые 2 секунды"}>{connected ? "Синхронизация · 2 с" : "Переподключение…"}</span>
            </span>
          </div>
            <VideoPlayer
              room={room}
              control={control && connected}
              call={call}
              notify={notify}
              clockOffset={clockOffset}
              onAdd={() => setModal("media")}
              onNext={
                user.premium && user.preferences?.autoNext
                  ? async () => {
                      const media = room.state.media;
                      if (!media?.releaseId) return;
                      const release = await api(`/anime/${media.releaseId}`);
                      const next = release.episodeList.find(
                        (e) => e.episode > media.episode,
                      );
                      if (!next) return;
                      const selected = await call("anime:select", {
                        releaseId: media.releaseId,
                        episode: next.episode,
                      });
                      await call("media:sync", { position: 0, playing: true, mediaVersion: selected.room.state.mediaVersion });
                    }
                  : null
              }
            />
          <div className="watch-footer">
            <div className="controller">
              <span className="controller-icon">
                <MousePointer2 size={15} />
              </span>
              <span>
                Управляет{" "}
                <strong>
                  {control
                    ? "вы"
                    : activeController?.name || "владелец комнаты"}
                </strong>
              </span>
            </div>
            <div className="watch-people">
              <Users size={15} />
              {users.length} {users.length === 1 ? "участник" : "в комнате"}
            </div>
          </div>
          {!mobile && roomLibrary}
        </div>
        <aside className="chat-panel">
          <div className="chat-tabs">
            <button
              className={tab === "chat" ? "active" : ""}
              onClick={() => setTab("chat")}
            >
              <MessageCircle size={16} />
              Чат
            </button>
            <button
              className={tab === "users" ? "active" : ""}
              onClick={() => setTab("users")}
            >
              <Users size={16} />
              Участники <small>{users.length}</small>
            </button>
            {mobile && (
              <button
                className={tab === "library" ? "active" : ""}
                onClick={() => setTab("library")}
              >
                <Film size={16} /> Серии
              </button>
            )}
          </div>
          {mobile && tab === "library" ? (
            <div className="mobile-room-library">{roomLibrary}</div>
          ) : tab === "chat" || (!mobile && tab === "library") ? (
            <>
              <div className="chat-messages">
                <div className="chat-welcome">
                  <div className="chat-welcome-icon">
                    <MessageCircle size={22} />
                  </div>
                  <strong>Устраивайтесь поудобнее</strong>
                  <p>
                    Делитесь впечатлениями.
                    <br />
                    Этот вечер — для вас.
                  </p>
                  <span>НАЧАЛО ВАШЕЙ ИСТОРИИ</span>
                </div>
                {messages.map((m) => (
                  <div
                    className={`chat-message ${m.userId === user.id ? "own" : ""}`}
                    key={m.id}
                  >
                    <Avatar user={m} size="small" />
                    <div>
                      <div className="message-meta">
                        <strong>
                          <UserName user={m} />
                        </strong>
                        <time>
                          {new Date(m.created).toLocaleTimeString("ru", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </time>
                      </div>
                      <p>{m.body}</p>
                      {user.role === "admin" && (
                        <button
                          className="delete-message"
                          aria-label="Удалить сообщение"
                          onClick={async () => {
                            try {
                              await api(`/admin/messages/${m.id}`, {
                                method: "DELETE",
                              });
                            } catch (e) {
                              notify(e.message);
                            }
                          }}
                        >
                          <Trash2 size={12} />
                          Удалить
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>
              <ChatComposer
                disabled={!connected}
                onSend={(body) => call("chat:send", { body })}
              />
              <div className="chat-footnote">
                <span className="status-dot" />
                Только для участников комнаты
              </div>
            </>
          ) : (
            <div className="participants">
              {users.map((u) => (
                <div className="participant" key={u.id}>
                  <Avatar user={u} />
                  <div>
                    <strong>
                      <UserName user={u} />
                      {u.id === user.id ? " (вы)" : ""}
                    </strong>
                    <small>
                      {u.id === room.owner
                        ? "Владелец"
                        : u.id === room.controller
                          ? "Управляет просмотром"
                          : "Участник"}
                    </small>
                  </div>
                  {u.id === room.controller ? (
                    <MousePointer2 size={16} />
                  ) : (
                    room.owner === user.id && (
                      <button
                        title="Передать управление"
                        aria-label={`Передать управление ${u.name}`}
                        onClick={() => action("room:control", { userId: u.id })}
                      >
                        <MousePointer2 size={16} />
                      </button>
                    )
                  )}
                </div>
              ))}
              <p className="form-hint">
                Участник с управлением выбирает видео и позицию
                воспроизведения.
              </p>
            </div>
          )}
        </aside>
      </div>
      {modal && (
        <Modal close={() => setModal(false)}>
          {modal === "invite" ? (
            <>
              <h2>Приглашение в комнату</h2>
              <label>
                Скопируйте эту ссылку
                <input
                  readOnly
                  value={location.href}
                  onFocus={(e) => e.target.select()}
                />
              </label>
            </>
          ) : modal === "delete" ? (
            <>
              <h2>Удалить комнату?</h2>
              <p className="muted">Комната и её история чата будут удалены для всех участников. Это действие нельзя отменить.</p>
              <button className="primary full" disabled={busy} onClick={async () => {
                setBusy(true);
                try {
                  await api(`/rooms/${id}`, { method: "DELETE" });
                  onLeave();
                  notify("Комната удалена.");
                } catch (error) { notify(error.message); }
                finally { setBusy(false); }
              }}>{busy ? "Удаляем…" : "Удалить комнату"}</button>
            </>
          ) : (
            <MediaForm
              onSubmit={async (media) => {
                await call("media:select", { media });
                setModal(false);
              }}
            />
          )}
        </Modal>
      )}
    </main>
  );
}
function ChatComposer({ disabled, onSend }) {
  const [text, setText] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <form
      className="chat-composer"
      onSubmit={async (e) => {
        e.preventDefault();
        if (disabled || busy || !text.trim()) return;
        const submitted = text;
        setBusy(true);
        try {
          await onSend(submitted);
          setText((current) => (current === submitted ? "" : current));
        } catch {
        } finally {
          setBusy(false);
        }
      }}
    >
      <input
        aria-label="Сообщение"
        placeholder="Что думаете?"
        value={text}
        maxLength={2000}
        onChange={(e) => setText(e.target.value)}
        disabled={disabled}
      />
      <button
        aria-label="Отправить сообщение"
        disabled={disabled || busy || !text.trim()}
      >
        <Send size={17} />
      </button>
    </form>
  );
}
function VideoPlayer({
  room,
  control,
  call,
  notify,
  clockOffset,
  onAdd,
  onNext,
}) {
  const ref = useRef(),
    playerRef = useRef(),
    nativeFullscreen = useRef(false),
    tap = useRef(null),
    feedbackTimer = useRef(),
    latest = useRef(room.state),
    changingSource = useRef(false),
    controlRef = useRef(control);
  const [quality, setQuality] = useState(""),
    [voice, setVoice] = useState(""),
    [duration, setDuration] = useState(0),
    [position, setPosition] = useState(0),
    [volume, setVolume] = useState(0.8),
    [needsGesture, setNeedsGesture] = useState(false),
    [videoError, setVideoError] = useState(""),
    [loadAttempt, setLoadAttempt] = useState(0),
    [fullscreen, setFullscreen] = useState(false),
    [seekFeedback, setSeekFeedback] = useState(null);
  latest.current = room.state;
  controlRef.current = control;
  const media = room.state.media,
    sources = media?.sources || [],
    voices = [...new Set(sources.map((s) => s.voice))],
    selectedVoice = voices.includes(voice) ? voice : voices[0],
    available = sources.filter((s) => s.voice === selectedVoice),
    source = available.find((s) => s.quality === quality) || available[0];
  const targetTime = () =>
    latest.current.position +
    (latest.current.playing
      ? Math.max(
          0,
          Date.now() + clockOffset.current - latest.current.updatedAt,
        ) / 1000
      : 0);
  const apply = () => {
    const video = ref.current;
    if (!video || !video.readyState) return;

    const target = targetTime();
    if (Math.abs(video.currentTime - target) > 1.25)
      video.currentTime = Number.isFinite(video.duration)
        ? Math.min(target, video.duration)
        : target;
    if (latest.current.playing)
      video
        .play()
        .then(() => setNeedsGesture(false))
        .catch(() => setNeedsGesture(true));
    else video.pause();
  };
  useEffect(() => {
    apply();
  }, [room.state.updatedAt, room.state.playing]);
  useEffect(() => {
    const video = ref.current;
    if (!video || !source) return;
    changingSource.current = true;
    setVideoError("");
    setDuration(0);
    if (
      media.provider === "anilibria" &&
      (!video.canPlayType('video/mp4; codecs="avc1.42E01E"') ||
        !video.canPlayType('audio/mp4; codecs="mp4a.40.2"'))
    ) {
      setVideoError(
        "Этот браузер не поддерживает H.264/AAC. Откройте сайт в Chrome, Edge или Safari с поддержкой этих кодеков.",
      );
      return;
    }
    let hls;
    if (
      /\.m3u8(?:\?|$)/i.test(source.url) &&
      !(
        video.webkitEnterFullscreen &&
        video.canPlayType("application/vnd.apple.mpegurl")
      ) &&
      Hls.isSupported()
    ) {
      hls = new Hls({ startPosition: targetTime() });
      hls.loadSource(source.url);
      hls.attachMedia(video);
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal)
          setVideoError(
            "Не удалось загрузить поток. Проверьте URL и доступ к источнику.",
          );
      });
    } else {
      video.src = source.url;
      video.load();
    }
    return () => {
      changingSource.current = true;
      hls?.destroy();
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [source?.url, loadAttempt]);
  useEffect(() => {
    const timer = setInterval(() => {
      if (controlRef.current) {
        const video = ref.current;
        // A source switch or pending play() may temporarily pause the element.
        // Do not publish that transient state as a user pause to the room.
        if (
          video?.readyState >= 2 &&
          !changingSource.current &&
          latest.current.media &&
          video.paused === !latest.current.playing
        )
          call("media:sync", {
            position: video.currentTime,
            playing: latest.current.playing,
            mediaVersion: latest.current.mediaVersion || 0,
          }).catch(() => {});
      } else apply();
    }, 3000);
    return () => clearInterval(timer);
  }, []);
  const sync = (playing, pos = ref.current?.currentTime || 0) =>
    call("media:sync", { position: pos, playing, mediaVersion: latest.current.mediaVersion || 0 }).catch(() => {});
  useEffect(() => {
    const video = ref.current;
    const update = () =>
      setFullscreen(
        Boolean(document.fullscreenElement || document.webkitFullscreenElement),
      );
    const begin = () => {
      nativeFullscreen.current = true;
      setFullscreen(true);
    };
    const end = () => {
      nativeFullscreen.current = false;
      setFullscreen(false);
      apply();
    };
    document.addEventListener("fullscreenchange", update);
    document.addEventListener("webkitfullscreenchange", update);
    video?.addEventListener("webkitbeginfullscreen", begin);
    video?.addEventListener("webkitendfullscreen", end);
    return () => {
      document.removeEventListener("fullscreenchange", update);
      document.removeEventListener("webkitfullscreenchange", update);
      video?.removeEventListener("webkitbeginfullscreen", begin);
      video?.removeEventListener("webkitendfullscreen", end);
      clearTimeout(tap.current?.timer);
      tap.current = null;
      clearTimeout(feedbackTimer.current);
    };
  }, [Boolean(media)]);
  useEffect(() => {
    clearTimeout(tap.current?.timer);
    tap.current = null;
  }, [source?.url, control]);
  const seek = (delta) => {
    const video = ref.current;
    if (
      !controlRef.current ||
      !video?.readyState ||
      !Number.isFinite(video.duration)
    )
      return;
    const next = Math.max(
      0,
      Math.min(video.duration, video.currentTime + delta),
    );
    video.currentTime = next;
    setPosition(next);
    sync(latest.current.playing, next);
    setSeekFeedback(delta);
    clearTimeout(feedbackTimer.current);
    feedbackTimer.current = setTimeout(() => setSeekFeedback(null), 700);
  };
  const tapVideo = (event) => {
    if (!controlRef.current) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const side = event.clientX < rect.left + rect.width / 2 ? -10 : 10;
    const now = Date.now();
    if (
      tap.current &&
      now - tap.current.at < 320 &&
      tap.current.side === side
    ) {
      clearTimeout(tap.current.timer);
      tap.current = null;
      seek(side);
    } else {
      clearTimeout(tap.current?.timer);
      tap.current = {
        at: now,
        side,
        timer: setTimeout(() => {
          tap.current = null;
          if (controlRef.current) sync(!latest.current.playing);
        }, 320),
      };
    }
  };
  const toggleFullscreen = async () => {
    const video = ref.current,
      player = playerRef.current;
    try {
      if (nativeFullscreen.current) return video.webkitExitFullscreen();
      if (document.fullscreenElement) return await document.exitFullscreen();
      if (document.webkitFullscreenElement)
        return document.webkitExitFullscreen();
      if (player.requestFullscreen && document.fullscreenEnabled !== false) {
        try {
          await player.requestFullscreen();
          return;
        } catch (error) {
          if (!video?.webkitEnterFullscreen) throw error;
        }
      }
      if (video?.webkitEnterFullscreen) return video.webkitEnterFullscreen();
      if (player.webkitRequestFullscreen)
        return player.webkitRequestFullscreen();
      notify("Полноэкранный режим недоступен в этом браузере.");
    } catch {
      notify(
        "Не удалось открыть полный экран. Дождитесь загрузки видео и попробуйте снова.",
      );
    }
  };
  const nativeChange = (event) => {
    const video = ref.current;
    if (
      !nativeFullscreen.current ||
      changingSource.current ||
      !video ||
      video.readyState < 2 ||
      video.ended
    )
      return;
    if (!controlRef.current) {
      apply();
      return;
    }
    // Ignore events caused by applying shared state, but preserve immediate
    // native play/pause after seeking (no time-based suppression window).
    if (event.type === "seeked") {
      if (Math.abs(video.currentTime - targetTime()) > 1.25)
        sync(latest.current.playing);
    } else if (video.paused !== !latest.current.playing) sync(!video.paused);
  };
  return (
    <div ref={playerRef} className="video-player">
      <div className="video-stage">
        {media ? (
          <>
            <video
              ref={ref}
              playsInline
              preload="metadata"
              onLoadedMetadata={() => {
                changingSource.current = false;
                setDuration(ref.current.duration);
                ref.current.volume = volume;
                apply();
              }}
              onTimeUpdate={() => setPosition(ref.current.currentTime)}
              onEnded={async () => {
                if (!control) return;
                await sync(false, ref.current.duration);
                if (onNext)
                  try {
                    await onNext();
                  } catch (e) {
                    notify(e.message);
                  }
              }}
              onError={() =>
                setVideoError(
                  "Видео недоступно. Проверьте ссылку, формат и разрешение доступа.",
                )
              }
              onPlay={nativeChange}
              onPause={nativeChange}
              onSeeked={nativeChange}
              onClick={tapVideo}
            />
            {seekFeedback !== null && (
              <div
                className={`seek-feedback ${seekFeedback < 0 ? "back" : "forward"}`}
                role="status"
              >
                {seekFeedback > 0 ? "+" : "−"}10 с
              </div>
            )}
            {needsGesture && (
              <button
                className="enable-playback"
                onClick={() =>
                  ref.current
                    .play()
                    .then(() => setNeedsGesture(false))
                    .catch(() => notify("Браузер не смог воспроизвести видео."))
                }
              >
                <Volume2 size={18} />
                Разрешить воспроизведение
              </button>
            )}
            {videoError && (
              <div className="video-error">
                <Film size={25} />
                <p>{videoError}</p>
                <button
                  className="secondary"
                  onClick={() => setLoadAttempt((n) => n + 1)}
                >
                  Повторить загрузку
                </button>
                {control && (
                  <button className="secondary" onClick={onAdd}>
                    Другой источник
                  </button>
                )}
              </div>
            )}
          </>
        ) : (
          <div className="browser-idle">
            <div className="large-icon">
              <Film size={35} />
            </div>
            <span className="eyebrow">СМОТРИМ СИНХРОННО</span>
            <h2>Выберите историю для вечера.</h2>
            <p>
              Добавьте прямую ссылку на видео или выберите
              <br />
              серию из библиотеки ниже.
            </p>
            <button className="primary" disabled={!control} onClick={onAdd}>
              <Plus size={17} />
              Добавить видео
            </button>
          </div>
        )}
      </div>
      {media && (
        <>
          <div className="video-controls">
            <input
              className="timeline"
              aria-label="Позиция воспроизведения"
              type="range"
              min="0"
              max={Number.isFinite(duration) ? duration : 0}
              step="0.1"
              value={Math.min(position, duration || 0)}
              disabled={!control || !duration}
              onChange={(e) => {
                ref.current.currentTime = +e.target.value;
                setPosition(+e.target.value);
                sync(room.state.playing, +e.target.value);
              }}
            />
            <div className="player-buttons">
              <button
                aria-label={room.state.playing ? "Пауза" : "Воспроизвести"}
                disabled={!control}
                onClick={() => sync(!room.state.playing)}
              >
                {room.state.playing ? <Pause size={19} /> : <Play size={19} />}
              </button>
              <button
                aria-label="Назад на 10 секунд"
                disabled={!control || !duration}
                onClick={() => seek(-10)}
              >
                <RotateCcw size={17} />
              </button>
              <button
                aria-label="Вперёд на 10 секунд"
                disabled={!control || !duration}
                onClick={() => seek(10)}
              >
                <RotateCw size={17} />
              </button>
              <span className="time-display">
                {time(position)} / {time(duration)}
              </span>
              <button
                aria-label={volume ? "Выключить звук" : "Включить звук"}
                onClick={() => {
                  const v = volume ? 0 : 0.8;
                  setVolume(v);
                  ref.current.volume = v;
                }}
              >
                {volume ? <Volume2 size={17} /> : <VolumeX size={17} />}
              </button>
              <input
                type="range"
                className="volume"
                aria-label="Громкость"
                min="0"
                max="1"
                step=".05"
                value={volume}
                onChange={(e) => {
                  setVolume(+e.target.value);
                  ref.current.volume = +e.target.value;
                }}
              />
              <span className="player-spacer" />
              <button
                aria-label={
                  fullscreen ? "Выйти из полного экрана" : "Полный экран"
                }
                onClick={toggleFullscreen}
              >
                {fullscreen ? <Minimize size={17} /> : <Maximize size={17} />}
              </button>
            </div>
          </div>
          <div className="media-details">
            <div>
              <strong>{media.title}</strong>
              <span>Серия {media.episode}</span>
            </div>
            <label>
              <Volume2 size={14} />
              <select
                aria-label="Озвучка"
                value={selectedVoice}
                onChange={(e) => setVoice(e.target.value)}
              >
                {voices.map((v) => (
                  <option key={v}>{v}</option>
                ))}
              </select>
            </label>
            <label>
              <Settings2 size={14} />
              <select
                aria-label="Качество"
                value={source?.quality || ""}
                onChange={(e) => setQuality(e.target.value)}
              >
                {available.map((s) => (
                  <option key={s.quality}>{s.quality}</option>
                ))}
              </select>
            </label>
          </div>
        </>
      )}
    </div>
  );
}
function time(s) {
  if (!Number.isFinite(s)) return "0:00";
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}
function MediaForm({ onSubmit }) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [variants, setVariants] = useState([
      { url: "", quality: "1080p", voice: "Оригинал" },
    ]);
  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        const form = new FormData(e.currentTarget);
        setBusy(true);
        try {
          await onSubmit({
            title: form.get("title"),
            episode: Number(form.get("episode")),
            sources: variants,
          });
        } catch (e) {
          setError(e.message);
        } finally {
          setBusy(false);
        }
      }}
    >
      <div className="modal-symbol">
        <Film size={26} />
      </div>
      <h2>Что будем смотреть?</h2>
      <p className="muted">
        Прямая ссылка на MP4, WebM или HLS. Источник должен разрешать
        воспроизведение в браузере.
      </p>
      <div className="form-row">
        <label>
          Название
          <input
            name="title"
            placeholder="Название видео или аниме"
            required
            maxLength={200}
          />
        </label>
        <label className="episode-input">
          Серия
          <input
            name="episode"
            type="number"
            min="1"
            max="10000"
            defaultValue="1"
            required
          />
        </label>
      </div>
      {variants.map((v, index) => (
        <div className="source-inputs" key={index}>
          <label>
            Ссылка на видео
            <input
              type="url"
              aria-label={`Источник ${index + 1}`}
              placeholder="https://example.com/video.mp4"
              required
              value={v.url}
              onChange={(e) =>
                setVariants((a) =>
                  a.map((s, i) =>
                    i === index ? { ...s, url: e.target.value } : s,
                  ),
                )
              }
            />
          </label>
          <div className="form-row">
            <label>
              Озвучка
              <input
                value={v.voice}
                maxLength={40}
                required
                onChange={(e) =>
                  setVariants((a) =>
                    a.map((s, i) =>
                      i === index ? { ...s, voice: e.target.value } : s,
                    ),
                  )
                }
              />
            </label>
            <label>
              Качество
              <input
                value={v.quality}
                maxLength={20}
                required
                onChange={(e) =>
                  setVariants((a) =>
                    a.map((s, i) =>
                      i === index ? { ...s, quality: e.target.value } : s,
                    ),
                  )
                }
              />
            </label>
          </div>
        </div>
      ))}
      {variants.length < 8 && (
        <button
          type="button"
          className="text-button"
          onClick={() =>
            setVariants((a) => [
              ...a,
              { url: "", quality: "720p", voice: "Оригинал" },
            ])
          }
        >
          <Plus size={15} />
          Добавить качество или озвучку
        </button>
      )}
      {error && <p className="form-error">{error}</p>}
      <button className="primary full" disabled={busy}>
        {busy ? "Добавляем…" : "Открыть в комнате"}
        <ArrowRight size={17} />
      </button>
    </form>
  );
}

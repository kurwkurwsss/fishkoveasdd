import React, { useEffect, useState } from "react";
import { Play, Users, Bookmark, Star } from "lucide-react";
import { api } from "./api";

export function AnimeDetail({ anime, saved, onFavorite, onWatch }) {
  const [release, setRelease] = useState(null);
  const [error, setError] = useState("");
  const [episode, setEpisode] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let cancelled = false;
    setError("");
    setRelease(null);
    if (anime.provider !== "anilibria") return;
    api(`/anime/${anime.releaseId}`)
      .then((data) => {
        if (cancelled) return;
        setRelease(data);
        setEpisode(String(data.episodeList[0]?.episode || ""));
      })
      .catch((e) => {
        if (!cancelled) setError(e.message);
      });
    return () => {
      cancelled = true;
    };
  }, [anime.releaseId, attempt]);
  return (
    <div className="anime-detail">
      <img src={anime.poster} alt={anime.title} />
      <div>
        <span className="eyebrow">
          {anime.type} • {anime.year} • {anime.episodes || "?"} СЕРИЙ
        </span>
        <h2>{anime.title}</h2>
        {anime.score && (
          <span className="detail-rating">
            <Star size={15} fill="currentColor" />
            {anime.score} <span>оценка {anime.scoreSource || "Kitsu"}</span>
          </span>
        )}
        <p>{anime.description || "Описание пока не добавлено."}</p>
        {release?.episodeList.length > 0 && (
          <label>
            Начать с серии
            <select
              aria-label="Начать с серии"
              value={episode}
              onChange={(e) => setEpisode(e.target.value)}
            >
              {release.episodeList.map((item) => (
                <option key={item.episode} value={item.episode}>
                  {item.episode} серия — {item.name}
                </option>
              ))}
            </select>
          </label>
        )}
        {error && (
          <div className="form-error">
            {error}{" "}
            <button onClick={() => setAttempt((n) => n + 1)}>Повторить</button>
          </div>
        )}
        {release?.availability && (
          <p className="source-note">{release.availability}</p>
        )}
        <div className="detail-actions">
          <button
            className="primary"
            disabled={anime.provider === "anilibria" && (!release || !episode)}
            onClick={() =>
              onWatch(
                anime.provider === "anilibria"
                  ? {
                      releaseId: anime.releaseId,
                      episode: Number(episode),
                      title: anime.title,
                    }
                  : null,
              )
            }
          >
            <Users size={17} />
            {!release && !error && anime.provider === "anilibria"
              ? "Загружаем серии…"
              : "Смотреть вместе"}
          </button>
          <button className="secondary" onClick={onFavorite}>
            <Bookmark size={17} />
            {saved ? "Сохранено" : "На потом"}
          </button>
        </div>
        <div className="source-note">
          AniLibria · русская озвучка · HLS. Качество и громкость выбираются в
          плеере; серия, пауза и время просмотра общие для комнаты.
        </div>
      </div>
    </div>
  );
}

export function AnimeLibrary({ releaseId, media, disabled, onSelect }) {
  const [query, setQuery] = useState("");
  const [items, setItems] = useState([]);
  const [chosen, setChosen] = useState(releaseId || null);
  const [release, setRelease] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    if (releaseId) setChosen(releaseId);
  }, [releaseId]);
  useEffect(() => {
    let cancelled = false;
    if (!query.trim()) {
      setItems([]);
      setLoading(false);
      return;
    }
    const timer = setTimeout(() => {
      setLoading(true);
      setError("");
      api(`/catalog?q=${encodeURIComponent(query)}`)
        .then((data) => {
          if (!cancelled) setItems(data.items);
        })
        .catch((e) => {
          if (!cancelled) setError(e.message);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, attempt]);
  useEffect(() => {
    let cancelled = false;
    setRelease(null);
    setError("");
    if (!chosen) return;
    api(`/anime/${chosen}`)
      .then((data) => {
        if (!cancelled) setRelease(data);
      })
      .catch((e) => {
        if (!cancelled) setError(e.message);
      });
    return () => {
      cancelled = true;
    };
  }, [chosen, attempt]);
  return (
    <div className="anime-library">
      <label>
        Найти аниме для комнаты
        <input
          aria-label="Найти аниме для комнаты"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Название на русском или английском"
          maxLength={100}
        />
      </label>
      {loading && <p className="muted">Ищем в AniLibria…</p>}
      {query.trim() && !loading && !error && !items.length && (
        <p className="muted">Ничего не найдено.</p>
      )}
      <div className="anime-results">
        {items.map((anime) => (
          <button
            key={anime.id}
            className={chosen === anime.releaseId ? "selected" : ""}
            onClick={() => setChosen(anime.releaseId)}
          >
            {anime.title}
          </button>
        ))}
      </div>
      {error && (
        <p className="form-error">
          {error}{" "}
          <button onClick={() => setAttempt((n) => n + 1)}>Повторить</button>
        </p>
      )}
      {chosen && !release && !error && (
        <p className="muted">Загружаем серии…</p>
      )}
      {release && (
        <div className="series">
          <div>
            <strong>{release.title}</strong>
            <p>AniLibria · {release.episodeList.length} доступных серий</p>
          </div>
          {release.availability && (
            <p className="source-note">{release.availability}</p>
          )}
          <div className="episode-buttons">
            {release.episodeList.map((episode) => (
              <button
                key={episode.episode}
                title={episode.name}
                disabled={disabled}
                className={
                  media?.releaseId === release.releaseId &&
                  media?.episode === episode.episode
                    ? "selected"
                    : ""
                }
                onClick={() =>
                  onSelect({
                    releaseId: release.releaseId,
                    episode: episode.episode,
                  })
                }
              >
                <Play size={12} />
                {episode.episode} серия
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

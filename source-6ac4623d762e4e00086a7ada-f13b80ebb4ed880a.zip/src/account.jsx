import React, { useEffect, useState } from "react";
import {
  Crown,
  ShieldCheck,
  Palette,
  Camera,
  Check,
  Sparkles,
  Users,
  Film,
  MessageCircle,
  RefreshCw,
  MoonStar,
  Cat,
  Ghost,
  Orbit,
  Flower2,
} from "lucide-react";
import { api } from "./api";
export const themes = [
  {
    id: "midnight",
    name: "Полночь",
    description: "Тёмный графит и лаванда",
    colors: ["#15151e", "#bda6f7", "#343043"],
  },
  {
    id: "sakura",
    name: "Сакура",
    description: "Тёплый вечер в розовых тонах",
    colors: ["#21151d", "#f5a9c3", "#563244"],
  },
  {
    id: "ocean",
    name: "Океан",
    description: "Глубокий синий и мята",
    colors: ["#0b1c27", "#7cdacb", "#234555"],
  },
  {
    id: "daylight",
    name: "Рассвет",
    description: "Светлая тема для нового дня",
    colors: ["#f4f2fa", "#7451b2", "#e5dfee"],
  },
];
const avatars = {
  moon: "Луна",
  fox: "Лис",
  cat: "Кот",
  panda: "Панда",
  ghost: "Привидение",
  planet: "Планета",
  flower: "Цветок",
  crown: "Корона",
};
function AvatarGlyph({ id }) {
  if (id === "fox")
    return (
      <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M5 4L15 10L27 4L25 22L16 29L7 22Z" fill="currentColor" />
        <path d="M7 16L16 22L25 16L23 23L16 28L9 23Z" fill="#fff5df" />
        <circle cx="11" cy="15" r="1.5" fill="#412c3b" />
        <circle cx="21" cy="15" r="1.5" fill="#412c3b" />
        <path d="M13 22H19L16 25Z" fill="#412c3b" />
      </svg>
    );
  if (id === "panda")
    return (
      <svg viewBox="0 0 32 32" aria-hidden="true">
        <circle cx="8" cy="8" r="6" fill="currentColor" />
        <circle cx="24" cy="8" r="6" fill="currentColor" />
        <circle cx="16" cy="18" r="13" fill="#ecedf7" />
        <ellipse cx="10" cy="17" rx="4" ry="5" fill="#57426c" />
        <ellipse cx="22" cy="17" rx="4" ry="5" fill="#57426c" />
        <circle cx="11" cy="16" r="1.4" fill="white" />
        <circle cx="21" cy="16" r="1.4" fill="white" />
        <path d="M13 24L16 27L19 24Z" fill="#57426c" />
      </svg>
    );
  const Icon =
    {
      moon: MoonStar,
      cat: Cat,
      ghost: Ghost,
      planet: Orbit,
      flower: Flower2,
      crown: Crown,
    }[id] || MoonStar;
  return <Icon aria-hidden="true" strokeWidth={1.7} />;
}
export function Avatar({ user, size = "" }) {
  const custom = user?.avatar?.startsWith("/api/avatars/");
  return (
    <span
      className={`avatar ${size} avatar-art avatar-preset-${user?.avatar || "moon"} frame-${user?.premium ? user.preferences?.frame || "none" : "none"}`}
    >
      {custom ? (
        <img src={user.avatar} alt={`Аватар ${user.name}`} />
      ) : (
        <AvatarGlyph id={user?.avatar} />
      )}
    </span>
  );
}
export function UserName({ user }) {
  return (
    <span className="user-identity">
      <span
        className={`nickname name-${user?.premium ? user.preferences?.nameColor || "default" : "default"}`}
      >
        {user?.name}
      </span>
      {user?.role === "admin" ? (
        <span className="role-badge admin-badge">
          <ShieldCheck size={11} />
          АДМИН
        </span>
      ) : user?.premium ? (
        <span className="role-badge premium-badge">
          <Crown size={10} />
          PLUS
        </span>
      ) : null}
    </span>
  );
}
export function ThemePicker({ value, onChange, disabled = false }) {
  return (
    <div className="theme-grid">
      {themes.map((theme) => (
        <button
          disabled={disabled}
          type="button"
          key={theme.id}
          className={`theme-option ${value === theme.id ? "selected" : ""}`}
          onClick={() => onChange(theme.id)}
          aria-pressed={value === theme.id}
        >
          <span
            className="theme-preview"
            style={{ background: theme.colors[0] }}
          >
            <i style={{ background: theme.colors[2] }} />
            <b style={{ background: theme.colors[1] }} />
            {value === theme.id && (
              <Check size={18} style={{ color: theme.colors[1] }} />
            )}
          </span>
          <strong>{theme.name}</strong>
          <small>{theme.description}</small>
        </button>
      ))}
    </div>
  );
}
async function avatarData(file) {
  if (
    !file ||
    !["image/png", "image/jpeg", "image/webp"].includes(file.type) ||
    file.size > 6 * 1024 * 1024
  )
    throw new Error("Выберите PNG, JPEG или WebP до 6 МБ.");
  const bitmap = await createImageBitmap(file);
  try {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = 192;
    const context = canvas.getContext("2d");
    const side = Math.min(bitmap.width, bitmap.height);
    context.drawImage(
      bitmap,
      (bitmap.width - side) / 2,
      (bitmap.height - side) / 2,
      side,
      side,
      0,
      0,
      192,
      192,
    );
    return canvas.toDataURL("image/webp", 0.8);
  } finally {
    bitmap.close();
  }
}
export function ProfilePanel({
  user,
  onUser,
  theme,
  onTheme,
  onLogout,
  onRegister,
}) {
  const [name, setName] = useState(user.name),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [saved, setSaved] = useState("");
  async function update(body) {
    setBusy(true);
    setError("");
    setSaved("");
    try {
      const { user: updated } = await api("/profile", {
        method: "PATCH",
        body,
      });
      onUser(updated);
      setSaved("Сохранено");
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="account-panel">
      <div className="account-heading">
        <Avatar user={user} size="large" />
        <div>
          <span className="eyebrow">ВАШЕ МЕСТО В YORU</span>
          <h2>
            <UserName user={user} />
          </h2>
          <p className="muted">
            {user.role === "admin"
              ? "Администратор пространства"
              : user.email || "Гостевой профиль · без регистрации"}
          </p>
        </div>
      </div>
      <section className="settings-section">
        <h3>
          <Camera size={18} />
          Профиль
        </h3>
        <form
          className="nickname-form"
          onSubmit={(e) => {
            e.preventDefault();
            update({ name });
          }}
        >
          <label>
            Имя
            <input
              aria-label="Имя профиля"
              value={name}
              onChange={(e) => setName(e.target.value)}
              minLength={2}
              maxLength={40}
              required
              disabled={user.role === "admin"}
            />
          </label>
          <button
            className="secondary"
            disabled={busy || user.role === "admin"}
          >
            Сохранить имя
          </button>
        </form>
        <div className="avatar-choices">
          {Object.entries(avatars).map(([id]) => (
            <button
              key={id}
              type="button"
              disabled={busy}
              className={`avatar-preset-${id} ${user.avatar === id ? "selected" : ""}`}
              aria-label={`Аватар ${id}`}
              aria-pressed={user.avatar === id}
              onClick={() => update({ avatar: id })}
            >
              <AvatarGlyph id={id} />
            </button>
          ))}
          <label className="upload-avatar">
            <Camera size={19} />
            <span>Загрузить фото</span>
            <input
              aria-label="Загрузить аватарку"
              type="file"
              accept="image/png,image/jpeg,image/webp"
              disabled={busy}
              onChange={async (e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                try {
                  if (file) await update({ avatar: await avatarData(file) });
                } catch (error) {
                  setError(error.message);
                }
              }}
            />
          </label>
        </div>
      </section>
      <section className="settings-section">
        <h3>
          <Palette size={18} />
          Ваш стиль
        </h3>
        <ThemePicker
          value={theme}
          disabled={busy}
          onChange={async (value) => {
            await onTheme(value);
          }}
        />
      </section>
      <section className="premium-card">
        <div className="premium-title">
          <span className="premium-symbol">
            <Crown />
          </span>
          <div>
            <span className="eyebrow">БОЛЬШЕ ВАШЕГО ХАРАКТЕРА</span>
            <h3>
              Yoru Plus <span>Бесплатно навсегда</span>
            </h3>
          </div>
        </div>
        <p>
          Особенный профиль, уютный кинозал и ещё больше вечеров вместе. Без
          карты и подписки.
        </p>
        <div className="premium-features">
          <span>✦ Рамки и цвет ника</span>
          <span>✦ Режим кинотеатра</span>
          <span>✦ Следующая серия автоматически</span>
          <span>✦ До 50 своих комнат</span>
        </div>
        {!user.premium ? (
          <button
            className="primary"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              setError("");
              try {
                onUser(
                  (await api("/premium/activate", { method: "POST" })).user,
                );
                setSaved("Yoru Plus активирован!");
              } catch (e) {
                setError(e.message);
              } finally {
                setBusy(false);
              }
            }}
          >
            <Sparkles size={16} />
            Активировать бесплатно
          </button>
        ) : (
          <>
            <span className="premium-active">
              <Check size={15} />
              Yoru Plus активен
            </span>
            <div className="premium-options">
              <label>
                Рамка аватара
                <select
                  aria-label="Рамка аватара"
                  disabled={busy}
                  value={user.preferences?.frame || "none"}
                  onChange={(e) =>
                    update({ preferences: { frame: e.target.value } })
                  }
                >
                  <option value="none">Без рамки</option>
                  <option value="aurora">Северное сияние</option>
                  <option value="gold">Золотой ореол</option>
                </select>
              </label>
              <label>
                Цвет ника
                <select
                  aria-label="Цвет ника"
                  disabled={busy}
                  value={user.preferences?.nameColor || "default"}
                  onChange={(e) =>
                    update({ preferences: { nameColor: e.target.value } })
                  }
                >
                  <option value="default">Классический</option>
                  <option value="rose">Розовый</option>
                  <option value="mint">Мятный</option>
                  <option value="rainbow">Перелив</option>
                </select>
              </label>
            </div>
            <label className="toggle-setting">
              <input
                type="checkbox"
                checked={!!user.preferences?.autoNext}
                disabled={busy}
                onChange={(e) =>
                  update({ preferences: { autoNext: e.target.checked } })
                }
              />
              <span>
                Следующая серия автоматически
                <small>Когда вы управляете просмотром AniLibria</small>
              </span>
            </label>
          </>
        )}
      </section>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {saved && (
        <p className="save-status" role="status">
          ✓ {saved}
        </p>
      )}
      <div className="account-actions">
        {!user.email && user.role !== "admin" && (
          <button className="secondary" onClick={onRegister}>
            Сохранить профиль с email
          </button>
        )}
        <button className="secondary" onClick={onLogout}>
          Выйти из профиля
        </button>
      </div>
    </div>
  );
}
export function AdminPanel({ notify }) {
  const [overview, setOverview] = useState(null),
    [users, setUsers] = useState([]),
    [rooms, setRooms] = useState([]),
    [query, setQuery] = useState(""),
    [tab, setTab] = useState("users"),
    [page, setPage] = useState(1),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [revision, setRevision] = useState(0),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    const timer = setTimeout(
      () =>
        Promise.all([
          api("/admin/overview"),
          api(`/admin/${tab}?q=${encodeURIComponent(query)}&page=${page}`),
        ])
          .then(([stats, data]) => {
            if (active) {
              setOverview(stats);
              setUsers(data.users || []);
              setRooms(data.rooms || []);
            }
          })
          .catch((e) => {
            if (active) setError(e.message);
          })
          .finally(() => {
            if (active) setLoading(false);
          }),
      200,
    );
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [tab, query, page, revision]);
  async function action(path, method, body) {
    setBusy(true);
    try {
      await api(path, { method, body });
      setRevision((n) => n + 1);
    } catch (e) {
      notify(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="dashboard admin-dashboard">
      <div className="page-heading">
        <div>
          <span className="eyebrow">ПРОСТРАНСТВО ПОД ВАШЕЙ ЗАБОТОЙ</span>
          <h1>
            Панель администратора <ShieldCheck size={28} />
          </h1>
          <p>Пользователи, комнаты и порядок в чате.</p>
        </div>
        <button className="secondary" onClick={() => setRevision((n) => n + 1)}>
          <RefreshCw size={16} />
          Обновить
        </button>
      </div>
      <div className="admin-stats">
        {[
          [Users, "Пользователи", overview?.stats.users],
          [Film, "Комнаты", overview?.stats.rooms],
          [MessageCircle, "Сообщения", overview?.stats.messages],
          [Sparkles, "В сети", overview?.stats.online],
        ].map(([Icon, label, n]) => (
          <div key={label}>
            <Icon size={21} />
            <strong>{n ?? "—"}</strong>
            <span>{label}</span>
          </div>
        ))}
      </div>
      <div className="admin-toolbar">
        <div className="segmented">
          {["users", "rooms"].map((key) => (
            <button
              className={tab === key ? "selected" : ""}
              key={key}
              onClick={() => {
                setTab(key);
                setPage(1);
              }}
            >
              {key === "users" ? "Пользователи" : "Комнаты"}
            </button>
          ))}
        </div>
        {tab === "users" && (
          <input
            aria-label="Поиск пользователей"
            placeholder="Найти по имени…"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
          />
        )}
        <span className="muted">
          Хранилище: {overview?.database === "mysql" ? "MySQL" : "SQLite"}
        </span>
      </div>
      {error ? (
        <p className="form-error" role="alert">
          {error}
        </p>
      ) : loading ? (
        <p className="muted">Загружаем…</p>
      ) : (
        <div className="admin-list">
          {tab === "users"
            ? users.map((user) => (
                <article key={user.id}>
                  <Avatar user={user} />
                  <div>
                    <UserName user={user} />
                    <small>
                      {user.banned
                        ? "Заблокирован"
                        : user.email || "Гостевой профиль"}
                    </small>
                  </div>
                  {user.role !== "admin" && (
                    <button
                      className="secondary"
                      disabled={busy}
                      onClick={() => {
                        if (
                          user.banned ||
                          confirm(
                            `Заблокировать ${user.name}? Текущие сеансы будут завершены.`,
                          )
                        )
                          action(`/admin/users/${user.id}`, "PATCH", {
                            banned: !user.banned,
                          });
                      }}
                    >
                      {user.banned ? "Разблокировать" : "Заблокировать"}
                    </button>
                  )}
                </article>
              ))
            : rooms.map((room) => (
                <article key={room.id}>
                  <Film size={22} />
                  <div>
                    <strong>{room.name}</strong>
                    <small>Владелец: {room.owner}</small>
                  </div>
                  <button
                    className="secondary danger-text"
                    disabled={busy}
                    onClick={() => {
                      if (
                        confirm(
                          `Удалить комнату «${room.name}» и её сообщения?`,
                        )
                      )
                        action(`/admin/rooms/${room.id}`, "DELETE");
                    }}
                  >
                    Удалить
                  </button>
                </article>
              ))}
          {!(tab === "users" ? users : rooms).length && (
            <p className="muted">Ничего не найдено.</p>
          )}
        </div>
      )}
      <div className="admin-pagination">
        <button
          className="secondary"
          disabled={page === 1 || loading}
          onClick={() => setPage((p) => p - 1)}
        >
          Назад
        </button>
        <span>Страница {page}</span>
        <button
          className="secondary"
          disabled={loading || (tab === "users" ? users : rooms).length < 30}
          onClick={() => setPage((p) => p + 1)}
        >
          Далее
        </button>
      </div>
    </main>
  );
}

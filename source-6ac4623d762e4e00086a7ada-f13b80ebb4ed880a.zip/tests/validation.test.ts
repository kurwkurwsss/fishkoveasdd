import test from "node:test";
import assert from "node:assert/strict";
import { avatarImage, HttpError, publicUser, text, validateMedia } from "../netlify/lib/validation.js";

test("media accepts HTTPS and only the bundled relative demo files", () => {
  const media = { title: "Вечер", episode: 1, sources: [{ url: "https://video.example/watch.mp4", quality: "720p", voice: "Оригинал" }] };
  assert.equal(validateMedia(media).sources[0].url, media.sources[0].url);
  assert.equal(validateMedia({ ...media, sources: [{ ...media.sources[0], url: "/media/demo-720.webm" }] }).title, "Вечер");
  for (const url of ["http://video.example/watch.mp4", "javascript:alert(1)", "/other.webm", "https://viewer:example@video.example/watch.mp4"]) {
    assert.throws(() => validateMedia({ ...media, sources: [{ ...media.sources[0], url }] }), HttpError);
  }
  for (const episode of [0, -1, 1.5, 10001]) assert.throws(() => validateMedia({ ...media, episode }), HttpError);
  assert.throws(() => validateMedia({ ...media, sources: [] }), HttpError);
});

test("avatar uploads reject executable formats, invalid signatures and oversized images", () => {
  assert.throws(() => avatarImage("data:image/svg+xml;base64,PHN2Zz4="), HttpError);
  assert.throws(() => avatarImage("data:image/png;base64,aW52YWxpZA=="), HttpError);
  assert.throws(() => avatarImage("data:image/png;base64," + "A".repeat(90001)), HttpError);
  assert.throws(() => text(" ", "Имя", 2, 40), HttpError);
});

test("public profiles do not disclose email or account moderation fields", () => {
  const profile = { id: "participant", name: "Участник", email: "viewer@example.test", role: "user", avatar: "uploads/participant/photo", avatarVersion: 2, theme: "midnight", premium: false, banned: false, created: 1, preferences: {} };
  const visible = publicUser(profile);
  assert.equal(visible.avatar, "/api/avatars/participant?v=2");
  assert.equal(Object.hasOwn(visible, "email"), false);
  assert.equal(Object.hasOwn(visible, "banned"), false);
  assert.equal(publicUser(profile, true).email, profile.email);
});

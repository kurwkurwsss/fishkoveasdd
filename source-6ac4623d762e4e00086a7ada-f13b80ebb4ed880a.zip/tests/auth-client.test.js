import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

async function clientFixture(context, options = {}) {
  const calls = [];
  const identity = {
    getUser: async () => null,
    login: async (...args) => {
      calls.push(["login", ...args]);
      if (options.wrongPassword) throw new Error("fixture Identity failure");
    },
    logout: async () => calls.push(["logout"]),
    signup: async (...args) => {
      calls.push(["signup", ...args]);
      return options.confirmed ? { confirmedAt: "2026-10-01" } : {};
    },
  };
  context.mock.method(globalThis, "fetch", async (url, init) => {
    calls.push(["fetch", url, init]);
    return Response.json(url === "/api/auth/alias-login" ? { reload: true } : { user: { role: "user" } });
  });
  const key = `yoruAuthFixture${Math.random().toString(36).slice(2)}`;
  globalThis[key] = identity;
  const source = (await readFile(new URL("../src/api.js", import.meta.url), "utf8"))
    .replace('from "@netlify/identity";', `= globalThis[${JSON.stringify(key)}];`)
    .replace("import { getUser, login, logout, signup }", "const { getUser, login, logout, signup }");
  try {
    const { api } = await import(`data:text/javascript;base64,${Buffer.from(source).toString("base64")}`);
    return { api, calls };
  } finally { delete globalThis[key]; }
}

test("email login retains the browser Identity flow and loads the server profile", async (context) => {
  const { api, calls } = await clientFixture(context);
  const result = await api("/auth/login", { method: "POST", body: { email: " viewer@example.test ", password: "fixture-password" } });
  assert.deepEqual(calls[0], ["login", "viewer@example.test", "fixture-password"]);
  assert.equal(calls[1][1], "/api/me");
  assert.equal(result.user.role, "user");
});

test("alias login uses only the same-origin server endpoint and requests session reload", async (context) => {
  const { api, calls } = await clientFixture(context);
  assert.deepEqual(await api("/auth/login", { method: "POST", body: { email: "flovifly", password: "fixture-password" } }), { reload: true });
  assert.equal(calls.length, 1);
  assert.equal(calls[0][1], "/api/auth/alias-login");
  assert.equal(calls[0][2].credentials, "same-origin");
});

test("incorrect email passwords do not load a profile", async (context) => {
  const { api, calls } = await clientFixture(context, { wrongPassword: true });
  await assert.rejects(api("/auth/login", { method: "POST", body: { email: "viewer@example.test", password: "fixture-password" } }), /Не удалось войти/);
  assert.equal(calls.length, 1);
});

test("registration still uses Identity signup and requires email confirmation", async (context) => {
  const { api, calls } = await clientFixture(context);
  assert.deepEqual(await api("/auth/register", { method: "POST", body: { email: "viewer@example.test", password: "fixture-password", name: "Viewer" } }), { confirmationRequired: true });
  assert.deepEqual(calls[0], ["signup", "viewer@example.test", "fixture-password", { full_name: "Viewer" }]);
  assert.equal(calls.length, 1);
});

test("confirmed registration loads the server profile", async (context) => {
  const { api, calls } = await clientFixture(context, { confirmed: true });
  const result = await api("/auth/register", { method: "POST", body: { email: "viewer@example.test", password: "fixture-password", name: "Viewer" } });
  assert.equal(calls[1][1], "/api/me");
  assert.equal(result.user.role, "user");
});

test("guest login remains a server request without registered-account operations", async (context) => {
  const { api, calls } = await clientFixture(context);
  await api("/auth/guest", { method: "POST", body: { name: "Guest" } });
  assert.equal(calls.length, 1);
  assert.equal(calls[0][1], "/api/auth/guest");
  assert.deepEqual(JSON.parse(calls[0][2].body), { name: "Guest" });
});

import test from "node:test";
import type { TestContext } from "node:test";
import assert from "node:assert/strict";
import type { Context } from "@netlify/functions";
import { NodePgPreparedQuery } from "drizzle-orm/node-postgres/session";
import handler from "../netlify/functions/api.mjs";
import { requireAdmin } from "../netlify/lib/auth.js";
import { HttpError } from "../netlify/lib/validation.js";

function identityFixture(context: TestContext, options: { roles?: string[]; wrongPassword?: boolean; email?: string } = {}) {
  const runtime = globalThis as typeof globalThis & { Netlify?: unknown; netlifyIdentityContext?: unknown };
  const previousRuntime = runtime.Netlify;
  const previousIdentity = runtime.netlifyIdentityContext;
  const previousEmail = process.env.YORU_ADMIN_EMAIL;
  const cookies = new Map<string, string>();
  const requests: string[] = [];
  runtime.Netlify = {
    context: { url: "https://yoru.example.test", cookies: {
      get: (name: string) => cookies.get(name),
      set: ({ name, value }: { name: string; value: string }) => cookies.set(name, value),
      delete: (name: string) => cookies.delete(name),
    } },
  };
  runtime.netlifyIdentityContext = undefined;
  process.env.YORU_ADMIN_EMAIL = "admin@example.test";
  context.after(() => {
    runtime.Netlify = previousRuntime;
    runtime.netlifyIdentityContext = previousIdentity;
    if (previousEmail === undefined) delete process.env.YORU_ADMIN_EMAIL;
    else process.env.YORU_ADMIN_EMAIL = previousEmail;
  });
  context.mock.method(globalThis, "fetch", async (url: string, init: RequestInit = {}) => {
    const path = new URL(url).pathname;
    requests.push(path);
    if (path.endsWith("/token")) {
      const body = new URLSearchParams(String(init.body));
      assert.equal(body.get("username"), "admin@example.test");
      assert.equal(body.get("password"), "fixture-password");
      if (options.wrongPassword) return Response.json({ error: "invalid_grant" }, { status: 400 });
      return Response.json({ access_token: "fixture-access", refresh_token: "fixture-refresh" });
    }
    if (path.endsWith("/user")) return Response.json({
      id: "fixture-admin", email: options.email || "admin@example.test",
      confirmed_at: "2026-10-01T00:00:00Z", app_metadata: { roles: options.roles ?? ["admin"] },
      user_metadata: { full_name: "flovifly", roles: ["admin"] },
    });
    if (path.endsWith("/logout")) return new Response(null, { status: 204 });
    throw new Error("Unexpected Identity request");
  });
  return { cookies, requests };
}

function aliasRequest(email = "flovifly", origin = "https://yoru.example.test") {
  return new Request("https://yoru.example.test/api/auth/alias-login", {
    method: "POST", headers: { "Content-Type": "application/json", Origin: origin },
    body: JSON.stringify({ email, password: "fixture-password" }),
  });
}

test("alias login uses the configured email and trusted Identity roles, without disclosing the mapping", async (context) => {
  const { cookies } = identityFixture(context);
  const response = await handler(aliasRequest(" FLOVIFLY "), {} as Context);
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { reload: true });
  assert.equal(cookies.has("nf_jwt"), true);
  assert.equal(cookies.has("nf_refresh"), true);
});

test("wrong password rejects alias login without setting an authenticated session", async (context) => {
  const { cookies } = identityFixture(context, { wrongPassword: true });
  const response = await handler(aliasRequest(), {} as Context);
  assert.equal(response.status, 401);
  assert.equal(cookies.size, 0);
});

test("a display name and user-controlled admin metadata do not authorize alias login", async (context) => {
  const { cookies, requests } = identityFixture(context, { roles: ["user"] });
  const response = await handler(aliasRequest(), {} as Context);
  assert.equal(response.status, 401);
  assert.equal(cookies.size, 0);
  assert.equal(requests.at(-1), "/.netlify/identity/logout");
});

test("alias login cannot authenticate a different Identity email", async (context) => {
  const { cookies } = identityFixture(context, { email: "other@example.test" });
  const response = await handler(aliasRequest(), {} as Context);
  assert.equal(response.status, 401);
  assert.equal(cookies.size, 0);
});

test("unconfigured and unknown aliases fail without calling Identity", async (context) => {
  const { requests } = identityFixture(context);
  delete process.env.YORU_ADMIN_EMAIL;
  assert.equal((await handler(aliasRequest(), {} as Context)).status, 503);
  assert.equal((await handler(aliasRequest("other-login"), {} as Context)).status, 401);
  assert.equal(requests.length, 0);
});

test("cross-origin alias login is denied before calling Identity", async (context) => {
  const { requests } = identityFixture(context);
  assert.equal((await handler(aliasRequest("flovifly", "https://other.example.test"), {} as Context)).status, 403);
  assert.equal(requests.length, 0);
});

test("the administrative API guard denies ordinary users and guests", () => {
  for (const role of ["user", "guest", "flovifly"]) {
    assert.throws(() => requireAdmin(role), (error: unknown) => error instanceof HttpError && error.status === 403);
  }
  assert.doesNotThrow(() => requireAdmin("admin"));
});

function databaseFixture(context: TestContext, rows: unknown[][]) {
  const previousUrl = process.env.NETLIFY_DB_URL;
  const previousDriver = process.env.NETLIFY_DB_DRIVER;
  process.env.NETLIFY_DB_URL = "postgresql://localhost/yoru_fixture";
  process.env.NETLIFY_DB_DRIVER = "server";
  let queries = 0;
  context.mock.method(NodePgPreparedQuery.prototype, "execute", async () => {
    const result = rows[queries++];
    assert.ok(result, "No additional database queries are allowed");
    return result;
  });
  context.after(() => {
    if (previousUrl === undefined) delete process.env.NETLIFY_DB_URL;
    else process.env.NETLIFY_DB_URL = previousUrl;
    if (previousDriver === undefined) delete process.env.NETLIFY_DB_DRIVER;
    else process.env.NETLIFY_DB_DRIVER = previousDriver;
  });
  return () => queries;
}

test("the actual admin endpoint denies an ordinary Identity user despite a stale admin profile", async (context) => {
  const { cookies } = identityFixture(context, { roles: ["user"] });
  cookies.set("nf_jwt", "fixture-access");
  const profile = { id: "fixture-admin", name: "flovifly", email: "admin@example.test", role: "admin", banned: false };
  const queries = databaseFixture(context, [[profile], [{ ...profile, role: "user" }]]);
  const response = await handler(new Request("https://yoru.example.test/api/admin/overview"), {} as Context);
  assert.equal(response.status, 403);
  assert.deepEqual(await response.json(), { error: "Нужны права администратора." });
  assert.equal(queries(), 2);
});

test("the reloaded session exposes the verified admin role for the existing menu and badge", async (context) => {
  const { cookies } = identityFixture(context);
  cookies.set("nf_jwt", "fixture-access");
  const profile = { id: "fixture-admin", name: "flovifly", email: "admin@example.test", role: "user", avatar: "moon", theme: "midnight", preferences: {}, banned: false };
  const queries = databaseFixture(context, [[profile], [{ ...profile, role: "admin" }]]);
  const response = await handler(new Request("https://yoru.example.test/api/me"), {} as Context);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).user.role, "admin");
  assert.equal(queries(), 2);
});

test("the guest endpoint preserves an existing server-issued guest session", async (context) => {
  const { requests } = identityFixture(context);
  const guest = { id: "fixture-guest", name: "Guest", role: "user", email: null, avatar: "moon", theme: "midnight", preferences: {}, banned: false };
  const queries = databaseFixture(context, [[{ user: guest }]]);
  const response = await handler(new Request("https://yoru.example.test/api/auth/guest", {
    method: "POST", headers: { "Content-Type": "application/json", Origin: "https://yoru.example.test", Cookie: `yoru_guest=${"a".repeat(43)}` },
    body: JSON.stringify({ name: "Guest" }),
  }), {} as Context);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).user.id, "fixture-guest");
  assert.equal(queries(), 1);
  assert.equal(requests.length, 0);
});

import test from "node:test";
import assert from "node:assert/strict";
import { fixture } from "./fixtures/anilibria.mjs";
import {
  catalog,
  normalizeRelease,
  release,
  animeMedia,
} from "../netlify/lib/catalog.js";

test("AniLibria: genuine qualities, ordered playable episodes and provider identity", async () => {
  const result = await catalog("Frieren", "fantasy");
  assert.equal(result.items[0].id, "anilibria:9542");
  assert.equal(result.items[0].poster, "https://anilibria.top/poster.jpg");
  assert.equal(result.items[0].scoreSource, "Shikimori");
  const anime = await release(9542);
  assert.deepEqual(
    anime.episodeList.map((e) => e.episode),
    [1, 2],
  );
  assert.deepEqual(
    anime.episodeList[0].sources.map((s) => s.quality),
    ["1080p", "480p"],
  );
  assert.equal(anime.episodeList[1].sources[0].voice, "AniLibria");
  const selected = await animeMedia(9542, 2);
  assert.equal(selected.releaseId, 9542);
  assert.equal(selected.episode, 2);
  await assert.rejects(animeMedia(9542, 3), /недоступна/);
  await assert.rejects(release("../secret"), /идентификатор/);
  await assert.rejects(release(999), /временно недоступна/);
});

test("restricted titles and absent HLS never become playable", async () => {
  for (const flag of ["is_blocked_by_geo", "is_blocked_by_copyrights"]) {
    const result = normalizeRelease({ ...fixture, [flag]: true });
    assert.deepEqual(result.episodeList, []);
    assert.match(result.availability, /ограничил/);
  }
  await assert.rejects(animeMedia(9543, 1), /ограничил/);
  const empty = normalizeRelease({
    ...fixture,
    episodes: [{ ordinal: 1, hls_480: "javascript:alert(1)" }],
  });
  assert.deepEqual(empty.episodeList, []);
  assert.match(empty.availability, /нет доступных/);
});

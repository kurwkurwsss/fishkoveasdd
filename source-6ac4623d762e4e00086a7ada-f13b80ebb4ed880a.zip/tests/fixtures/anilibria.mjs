export const fixture = {
  id: 9542,
  name: { main: "Фрирен", english: "Frieren" },
  description: "Тестовый релиз",
  year: 2023,
  type: { value: "TV" },
  poster: { src: "/poster.jpg" },
  shikimori: { rating: 8.84 },
  episodes_total: 3,
  age_rating: { is_adult: false },
  episodes: [
    {
      ordinal: 2,
      name: "Продолжение",
      hls_720: "https://cache.libria.fun/two.m3u8",
    },
    {
      ordinal: 1,
      name: "Начало",
      hls_1080: "https://cache.libria.fun/one1080.m3u8",
      hls_480: "https://cache.libria.fun/one480.m3u8",
    },
    { ordinal: 3, name: "Ещё нет видео" },
  ],
};
const originalFetch = globalThis.fetch;
globalThis.fetch = async (url, options) => {
  const parsed = new URL(url);
  if (parsed.origin !== "https://anilibria.top")
    return originalFetch(url, options);
  if (parsed.pathname.includes("/catalog/"))
    return Response.json({ data: [fixture] });
  if (parsed.pathname === "/api/v1/anime/releases/9542")
    return Response.json(fixture);
  if (parsed.pathname === "/api/v1/anime/releases/9543")
    return Response.json({
      ...fixture,
      id: 9543,
      is_blocked_by_copyrights: true,
    });
  return new Response(null, { status: 404 });
};

import { bigint, boolean, index, integer, jsonb, pgTable, primaryKey, text } from "drizzle-orm/pg-core";

export type Media = {
  title: string;
  episode: number;
  sources: { url: string; quality: string; voice: string }[];
  provider?: string;
  releaseId?: number;
};

export type PlaybackState = {
  mode: "video";
  media: Media | null;
  mediaVersion: number;
  position: number;
  playing: boolean;
  updatedAt: number;
};

export const users = pgTable("yoru_users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  role: text("role").notNull().default("user"),
  avatar: text("avatar").notNull().default("moon"),
  avatarVersion: bigint("avatar_version", { mode: "number" }).notNull().default(0),
  theme: text("theme").notNull().default("midnight"),
  premium: boolean("premium").notNull().default(false),
  banned: boolean("banned").notNull().default(false),
  preferences: jsonb("preferences").$type<{ frame?: string; nameColor?: string; autoNext?: boolean }>().notNull().default({}),
  lastMessageAt: bigint("last_message_at", { mode: "number" }).notNull().default(0),
  created: bigint("created", { mode: "number" }).notNull(),
});

export const guestSessions = pgTable("yoru_guest_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expires: bigint("expires", { mode: "number" }).notNull(),
}, (table) => [index("yoru_sessions_expires_idx").on(table.expires)]);

export const rooms = pgTable("yoru_rooms", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  owner: text("owner").notNull().references(() => users.id),
  controller: text("controller").notNull().references(() => users.id),
  state: jsonb("state").$type<PlaybackState>().notNull(),
  created: bigint("created", { mode: "number" }).notNull(),
}, (table) => [index("yoru_rooms_owner_idx").on(table.owner)]);

export const members = pgTable("yoru_members", {
  roomId: text("room_id").notNull().references(() => rooms.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  lastSeen: bigint("last_seen", { mode: "number" }).notNull(),
}, (table) => [primaryKey({ columns: [table.roomId, table.userId] }), index("yoru_members_user_idx").on(table.userId)]);

export const messages = pgTable("yoru_messages", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull().references(() => rooms.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  created: bigint("created", { mode: "number" }).notNull(),
}, (table) => [index("yoru_messages_room_created_idx").on(table.roomId, table.created)]);

export const favorites = pgTable("yoru_favorites", {
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  animeId: text("anime_id").notNull(),
  anime: jsonb("anime").$type<Record<string, unknown>>().notNull(),
}, (table) => [primaryKey({ columns: [table.userId, table.animeId] })]);

export const rateLimits = pgTable("yoru_rate_limits", {
  key: text("key").primaryKey(),
  hits: integer("hits").notNull().default(1),
  expires: bigint("expires", { mode: "number" }).notNull(),
}, (table) => [index("yoru_limits_expires_idx").on(table.expires)]);

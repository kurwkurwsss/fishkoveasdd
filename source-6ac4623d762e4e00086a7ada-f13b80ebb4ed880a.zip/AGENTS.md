# Yoru on Netlify

Yoru is a Russian-language watch-together application adapted from the supplied archive. The production deployment is entirely Netlify-hosted; it does not use an external Express server, WebSockets, Chromium, SQLite, or MySQL.

## Architecture

- `src/main.jsx`: React SPA shell, navigation, catalog, invitations, and auth dialogs.
- `src/room.jsx`: HLS/direct-video player, room polling, chat, participants, and playback controls.
- `src/account.jsx`: profiles, avatar presets/uploads, themes, free Plus, and moderation UI.
- `src/api.js`: same-origin JSON requests and registered-account flows with `@netlify/identity`.
- `src/password.jsx`: Identity invitation and password-recovery callbacks.
- `db/schema.ts`: sole database schema source, using Drizzle's PostgreSQL schema builder.
- `db/index.ts`: lazy Netlify Database client factory. Do not initialize the connection at module import time.
- `netlify/functions/api.mts`: modern Web API handler mounted at `/api/*`. Auth, ownership, and membership checks run on the server.
- `netlify/functions/cleanup.mts`: scheduled expiration of guest sessions and rate-limit buckets.
- `netlify/lib/catalog.js`: stateless AniLibria catalog/release adapter with a fixed upstream origin.
- `netlify/lib/validation.ts`: shared server-side validation and public profile serialization.
- `netlify/database/migrations/`: generated Drizzle migrations and snapshots; applied by the deploy pipeline.
- `public/media/`: actual demonstration videos from the supplied archive.
- `tests/`: catalog and server-side validator unit tests.

## Conventions

Use React functional components and preserve the existing Manrope/Unbounded typography, theme variables, and responsive layouts. Use TypeScript `.mts` for Netlify Functions, a default-exported handler, and an exported routing `config`. Imports in TypeScript use `.js` extensions for the build tool's resolution. The JavaScript catalog helper imports the shared TypeScript validator explicitly for compatibility with its unit-test runner. Preserve the existing formatting style; do not introduce another formatter.

Keep all structured state in Netlify Database through `@netlify/database` and `drizzle-orm@beta`. Install `drizzle-kit@beta` for migration generation. Define tables in `db/schema.ts`; generate migrations with `npm run db:generate -- --name descriptive_change`. Never run DDL directly against the database or edit applied migrations. Uploaded avatar binaries belong in Netlify Blobs, not the database or filesystem.

Registered accounts use `@netlify/identity`; administrator authorization comes exclusively from server-verified Identity roles. Guest profiles have independently generated, HTTP-only, same-site session cookies, with only token hashes persisted in Postgres. Guest data merges into the verified Identity account on the same browser after confirmation/login. Never log auth tokens, cookies, credentials, or environment values.

## Non-obvious Decisions

The CLI project link is persisted in `.netlify/state.json`, containing only the public project ID. `.gitignore` explicitly permits this file while excluding other local `.netlify` contents. Preserve the link for this deployment; never store authentication tokens in it. A fork targeting another Netlify project must update the link explicitly.

Room synchronization uses non-overlapping HTTP polling every two seconds, or fifteen seconds in a background tab. Presence expires after forty-five seconds. Room writes lock the room row in a transaction; only the controller may change playback, and only the owner may transfer control. The invitation link is a capability granting membership; room identifiers have 144 bits of randomness and are not publicly listed. Guests require an explicit server-issued session before joining.

The archived remote-browser mode requires a persistent process and has intentionally been removed. The Netlify version only advertises video playback and chat. Upstream video availability and CORS remain the source provider's responsibility. The uploaded MySQL CA certificate is not needed for managed Netlify Postgres and is not bundled into the site; no external database was connected or imported.

Identity activation is declared by `.netlify/features/netlify-identity`, written by the platform's Identity skill activation script. Do not remove it. Identity signups require email confirmation unless the site's administrator changes that setting. The first administrator receives the `admin` role through the Netlify Identity dashboard, never by choosing a display name.

During agent sessions, honor platform restrictions: do not start dev servers or run local builds, type checks, or tests when the task context forbids them. The deployment pipeline installs dependencies, applies migrations, and validates builds.

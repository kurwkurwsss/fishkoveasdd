import type { Config, Context } from "@netlify/functions";
import { getUser, verifyRequestOrigin } from "@netlify/identity";
import { getStore } from "@netlify/blobs";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { and, asc, count, desc, eq, gt, ilike, lt, ne, sql } from "drizzle-orm";
import { getDb } from "../../db/index.js";
import { favorites, guestSessions, members, messages, rateLimits, rooms, users } from "../../db/schema.js";
import { animeMedia, catalog, release } from "../lib/catalog.js";
import { loginAdminAlias, requireAdmin } from "../lib/auth.js";
import { avatarImage, HttpError, publicUser, text, validateMedia } from "../lib/validation.js";

function hash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function guestToken(request: Request) {
  const cookie = request.headers.get("cookie") || "";
  return /(?:^|;\s*)yoru_guest=([A-Za-z0-9_-]{43})(?:;|$)/.exec(cookie)?.[1];
}

function guestCookie(token: string, request: Request, clear = false) {
  return `yoru_guest=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${clear ? 0 : 2592000}${new URL(request.url).protocol === "https:" ? "; Secure" : ""}`;
}

async function currentUser(request: Request, database: ReturnType<typeof getDb>, headers: Headers) {
  const identity = await getUser();
  if (identity) {
    const role = identity.roles?.includes("admin") ? "admin" : "user";
    const name = (identity.name || identity.email?.split("@")[0] || "Участник").trim().slice(0, 40) || "Участник";
    let [user] = await database.select().from(users).where(eq(users.id, identity.id));
    if (!user) {
      await database.insert(users).values({ id: identity.id, name, email: identity.email || null, role, created: Date.now() }).onConflictDoNothing();
      [user] = await database.select().from(users).where(eq(users.id, identity.id));
    }
    if (user.role !== role || user.email !== (identity.email || null)) {
      [user] = await database.update(users).set({ email: identity.email || null, role }).where(eq(users.id, identity.id)).returning();
    }
    const token = guestToken(request);
    if (token && !user.banned) {
      user = await database.transaction(async (transaction) => {
        const [session] = await transaction.select().from(guestSessions).where(and(eq(guestSessions.tokenHash, hash(token)), gt(guestSessions.expires, Date.now())));
        if (!session || session.userId === identity.id) return user;
        const [guest] = await transaction.select().from(users).where(and(eq(users.id, session.userId), sql`${users.email} is null`)).for("update");
        if (!guest || guest.banned) return user;
        await transaction.update(rooms).set({ owner: user.id }).where(eq(rooms.owner, guest.id));
        await transaction.update(rooms).set({ controller: user.id }).where(eq(rooms.controller, guest.id));
        const memberships = await transaction.select().from(members).where(eq(members.userId, guest.id));
        if (memberships.length) await transaction.insert(members).values(memberships.map((membership) => ({ ...membership, userId: user.id }))).onConflictDoNothing();
        await transaction.delete(members).where(eq(members.userId, guest.id));
        await transaction.update(messages).set({ userId: user.id }).where(eq(messages.userId, guest.id));
        const saved = await transaction.select().from(favorites).where(eq(favorites.userId, guest.id));
        if (saved.length) await transaction.insert(favorites).values(saved.map((item) => ({ ...item, userId: user.id }))).onConflictDoNothing();
        await transaction.delete(favorites).where(eq(favorites.userId, guest.id));
        const [updated] = await transaction.update(users).set({
          avatar: user.avatar === "moon" ? guest.avatar : user.avatar,
          avatarVersion: user.avatar === "moon" ? guest.avatarVersion : user.avatarVersion,
          theme: guest.theme, premium: user.premium || guest.premium,
          preferences: { ...guest.preferences, ...user.preferences },
        }).where(eq(users.id, user.id)).returning();
        await transaction.delete(users).where(eq(users.id, guest.id));
        return updated;
      });
      headers.set("Set-Cookie", guestCookie("", request, true));
    }
    return user;
  }
  const token = guestToken(request);
  if (!token) return null;
  const [session] = await database.select({ user: users }).from(guestSessions)
    .innerJoin(users, eq(guestSessions.userId, users.id))
    .where(and(eq(guestSessions.tokenHash, hash(token)), gt(guestSessions.expires, Date.now())));
  return session?.user || null;
}

async function snapshot(database: ReturnType<typeof getDb>, roomId: string, userId: string) {
  const [room] = await database.select().from(rooms).where(eq(rooms.id, roomId));
  if (!room) throw new HttpError(404, "Комната не найдена или удалена.");
  const [membership] = await database.select().from(members).where(and(eq(members.roomId, roomId), eq(members.userId, userId)));
  if (!membership) throw new HttpError(403, "Сначала войдите в комнату по приглашению.");
  const now = Date.now();
  await database.update(members).set({ lastSeen: now }).where(and(eq(members.roomId, roomId), eq(members.userId, userId)));
  const people = await database.select({ user: users }).from(members).innerJoin(users, eq(members.userId, users.id))
    .where(and(eq(members.roomId, roomId), gt(members.lastSeen, now - 45000), eq(users.banned, false))).orderBy(asc(users.name));
  const chat = await database.select({ message: messages, user: users }).from(messages).innerJoin(users, eq(messages.userId, users.id))
    .where(eq(messages.roomId, roomId)).orderBy(desc(messages.created), desc(messages.id)).limit(100);
  return {
    room, users: people.map(({ user }) => publicUser(user)),
    messages: chat.reverse().map(({ message, user }) => ({ ...publicUser(user), ...message })),
    serverTime: Date.now(),
  };
}

async function readBody(request: Request) {
  if (!request.headers.get("content-type")?.startsWith("application/json"))
    throw new HttpError(415, "Ожидается JSON-запрос.");
  const raw = await request.text();
  if (Buffer.byteLength(raw) > 131072) throw new HttpError(413, "Запрос слишком большой.");
  try {
    const body = JSON.parse(raw);
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error();
    return body as Record<string, any>;
  } catch { throw new HttpError(400, "Некорректный JSON."); }
}

export default async (request: Request, context: Context) => {
  const headers = new Headers({ "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  const respond = (value: unknown, status = 200) => Response.json(value, { status, headers });
  try {
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/api/, "").replace(/\/$/, "");
    const method = request.method;
    if (!["GET", "POST", "PATCH", "DELETE"].includes(method)) return respond({ error: "Метод не поддерживается." }, 405);
    if (method !== "GET") verifyRequestOrigin(request);
    const body = method === "GET" ? {} : await readBody(request);
    if (path === "/catalog" && method === "GET") {
      return respond(await catalog(url.searchParams.get("q") || "", url.searchParams.get("genre") || ""));
    }
    if (/^\/anime\/\d+$/.test(path) && method === "GET") return respond(await release(path.split("/")[2]));
    if (path === "/library" && method === "GET") {
      return respond({ series: [{ id: "demo", title: "Проверка совместного просмотра", description: "Короткий ролик для проверки синхронизации и звука.", episodes: [{ title: "Цвет и звук", episode: 1, sources: [
        { quality: "720p", voice: "Тон 440 Гц", url: "/media/demo-720.webm" },
        { quality: "480p", voice: "Тон 440 Гц", url: "/media/demo-480.webm" },
      ] }] }] });
    }
    if (path === "/auth/alias-login" && method === "POST") {
      await loginAdminAlias(body, process.env.YORU_ADMIN_EMAIL);
      return respond({ reload: true });
    }
    const database = getDb();
    if (path === "/health" && method === "GET") {
      await database.select({ id: users.id }).from(users).limit(1);
      return respond({ ok: true, service: "yoru", database: "netlify-postgres", transport: "polling", sharedBrowser: false });
    }
    const avatarMatch = /^\/avatars\/([A-Za-z0-9_-]+)$/.exec(path);
    if (avatarMatch && method === "GET") {
      const [user] = await database.select().from(users).where(eq(users.id, avatarMatch[1]));
      if (!user?.avatar.startsWith("uploads/")) throw new HttpError(404, "Аватар не найден.");
      const image = await getStore({ name: "yoru-avatars", consistency: "strong" }).getWithMetadata(user.avatar, { type: "arrayBuffer" });
      if (!image) throw new HttpError(404, "Аватар не найден.");
      return new Response(image.data, { headers: { "Content-Type": String(image.metadata.contentType), "Cache-Control": "public, max-age=3600", "X-Content-Type-Options": "nosniff" } });
    }
    const user = await currentUser(request, database, headers);
    if (path === "/auth/logout" && method === "POST") {
      const token = guestToken(request);
      if (token) await database.delete(guestSessions).where(eq(guestSessions.tokenHash, hash(token)));
      headers.set("Set-Cookie", guestCookie("", request, true));
      return respond({ ok: true });
    }
    if (user?.banned) throw new HttpError(403, "Профиль заблокирован администратором.");
    if (path === "/me" && method === "GET") return respond({ user: user ? publicUser(user, true) : null });
    if (path === "/auth/guest" && method === "POST") {
      if (user) return respond({ user: publicUser(user, true) });
      const name = text(body.name, "Имя", 2, 40);
      const hour = Math.floor(Date.now() / 3600000);
      const key = `guest:${hash(context.ip)}:${hour}`;
      const [allowed] = await database.insert(rateLimits).values({ key, hits: 1, expires: (hour + 2) * 3600000 })
        .onConflictDoUpdate({ target: rateLimits.key, set: { hits: sql`${rateLimits.hits} + 1` }, setWhere: lt(rateLimits.hits, 10) }).returning();
      if (!allowed) throw new HttpError(429, "Слишком много гостевых входов. Попробуйте позже.");
      const token = randomBytes(32).toString("base64url");
      const created = await database.transaction(async (transaction) => {
        const [guest] = await transaction.insert(users).values({ id: randomUUID(), name, created: Date.now() }).returning();
        await transaction.insert(guestSessions).values({ tokenHash: hash(token), userId: guest.id, expires: Date.now() + 2592000000 });
        return guest;
      });
      headers.set("Set-Cookie", guestCookie(token, request));
      return respond({ user: publicUser(created, true) }, 201);
    }
    if (!user) throw new HttpError(401, "Войдите, чтобы продолжить.");
    if (path === "/profile" && method === "PATCH") {
      if (Object.keys(body).some((key) => !["name", "avatar", "theme", "preferences"].includes(key))) throw new HttpError(400, "Неизвестная настройка профиля.");
      const patch: Partial<typeof users.$inferInsert> = {};
      if (body.name !== undefined) patch.name = text(body.name, "Имя", 2, 40);
      if (body.theme !== undefined) {
        if (!["midnight", "sakura", "ocean", "daylight"].includes(body.theme)) throw new HttpError(400, "Неизвестная тема.");
        patch.theme = body.theme;
      }
      if (body.preferences !== undefined) {
        const preferences = body.preferences;
        if (!user.premium) throw new HttpError(403, "Сначала активируйте бесплатный Plus.");
        if (!preferences || typeof preferences !== "object" || Array.isArray(preferences) || Object.keys(preferences).some((key) => !["frame", "nameColor", "autoNext"].includes(key)) ||
          (preferences.frame !== undefined && !["none", "aurora", "gold"].includes(preferences.frame)) ||
          (preferences.nameColor !== undefined && !["default", "rose", "mint", "rainbow"].includes(preferences.nameColor)) ||
          (preferences.autoNext !== undefined && typeof preferences.autoNext !== "boolean")) throw new HttpError(400, "Некорректная настройка Plus.");
        patch.preferences = { ...user.preferences, ...preferences };
      }
      if (body.avatar !== undefined) {
        if (typeof body.avatar !== "string") throw new HttpError(400, "Некорректный аватар.");
        if (["moon", "fox", "cat", "panda", "ghost", "planet", "flower", "crown"].includes(body.avatar)) patch.avatar = body.avatar;
        else {
          const image = avatarImage(body.avatar);
          const key = `uploads/${user.id}/${randomUUID()}`;
          await getStore({ name: "yoru-avatars", consistency: "strong" }).set(key, new Blob([new Uint8Array(image.bytes)]), { metadata: { contentType: image.contentType } });
          patch.avatar = key;
        }
        patch.avatarVersion = Date.now();
      }
      if (!Object.keys(patch).length) return respond({ user: publicUser(user, true) });
      const [updated] = await database.update(users).set(patch).where(eq(users.id, user.id)).returning();
      if (patch.avatar && user.avatar.startsWith("uploads/")) await getStore("yoru-avatars").delete(user.avatar).catch(() => {});
      return respond({ user: publicUser(updated, true) });
    }
    if (path === "/premium/activate" && method === "POST") {
      const [updated] = await database.update(users).set({ premium: true }).where(eq(users.id, user.id)).returning();
      return respond({ user: publicUser(updated, true) });
    }
    if (path === "/favorites" && method === "GET") {
      const items = await database.select().from(favorites).where(eq(favorites.userId, user.id));
      return respond({ items: items.map((item) => item.anime) });
    }
    if (path === "/favorites" && method === "POST") {
      const anime = body.anime;
      if (!anime || typeof anime !== "object" || Array.isArray(anime)) throw new HttpError(400, "Некорректный тайтл.");
      const animeId = text(anime.id, "Тайтл", 1, 100);
      text(anime.title, "Название", 1, 200);
      if (JSON.stringify(anime).length > 16000) throw new HttpError(400, "Слишком большой тайтл.");
      await database.insert(favorites).values({ userId: user.id, animeId, anime }).onConflictDoNothing();
      return respond({ ok: true });
    }
    if (path.startsWith("/favorites/") && method === "DELETE") {
      await database.delete(favorites).where(and(eq(favorites.userId, user.id), eq(favorites.animeId, decodeURIComponent(path.slice(11)))));
      return respond({ ok: true });
    }
    if (path === "/rooms" && method === "GET") {
      const list = await database.select({ id: rooms.id, name: rooms.name, owner: rooms.owner, created: rooms.created,
        online: sql<number>`(select count(*)::int from ${members} as presence where presence.room_id = ${rooms.id} and presence.last_seen > ${Date.now() - 45000})`,
      }).from(members).innerJoin(rooms, eq(members.roomId, rooms.id))
        .where(eq(members.userId, user.id)).orderBy(desc(rooms.created)).limit(100);
      return respond({ rooms: list });
    }
    if (path === "/rooms" && method === "POST") {
      const name = text(body.name, "Название комнаты", 1, 40);
      let media = null;
      if (body.anime) {
        const selected = await animeMedia(body.anime.releaseId, body.anime.episode);
        media = { ...validateMedia(selected), provider: "anilibria", releaseId: selected.releaseId };
      }
      const room = await database.transaction(async (transaction) => {
        await transaction.select({ id: users.id }).from(users).where(eq(users.id, user.id)).for("update");
        const [total] = await transaction.select({ value: count() }).from(rooms).where(eq(rooms.owner, user.id));
        if (total.value >= (user.premium ? 50 : 20)) throw new HttpError(400, "Достигнут лимит комнат. Удалите ненужные комнаты.");
        const now = Date.now();
        const [created] = await transaction.insert(rooms).values({
          id: randomBytes(18).toString("base64url"), name, owner: user.id, controller: user.id,
          state: { mode: "video", media, mediaVersion: 0, position: 0, playing: false, updatedAt: now }, created: now,
        }).returning();
        await transaction.insert(members).values({ roomId: created.id, userId: user.id, lastSeen: now });
        return created;
      });
      return respond({ room }, 201);
    }
    const roomMatch = /^\/rooms\/([A-Za-z0-9_-]+)(?:\/(join|action|leave))?$/.exec(path);
    if (roomMatch) {
      const roomId = roomMatch[1];
      const route = roomMatch[2];
      if (route === "join" && method === "POST") {
        await database.transaction(async (transaction) => {
          const [room] = await transaction.select().from(rooms).where(eq(rooms.id, roomId)).for("update");
          if (!room) throw new HttpError(404, "Комната не найдена.");
          const [existing] = await transaction.select().from(members).where(and(eq(members.roomId, roomId), eq(members.userId, user.id)));
          if (!existing) {
            const [total] = await transaction.select({ value: count() }).from(members).where(eq(members.roomId, roomId));
            if (total.value >= 50) throw new HttpError(400, "В комнате уже 50 участников.");
          }
          await transaction.insert(members).values({ roomId, userId: user.id, lastSeen: Date.now() })
            .onConflictDoUpdate({ target: [members.roomId, members.userId], set: { lastSeen: Date.now() } });
        });
        return respond(await snapshot(database, roomId, user.id));
      }
      if (!route && method === "GET") return respond(await snapshot(database, roomId, user.id));
      if (!route && method === "DELETE") {
        const [deleted] = await database.delete(rooms).where(and(eq(rooms.id, roomId), eq(rooms.owner, user.id))).returning();
        if (!deleted) throw new HttpError(403, "Удалить комнату может только владелец.");
        return respond({ ok: true });
      }
      if (route === "leave" && method === "POST") {
        await database.update(members).set({ lastSeen: 0 }).where(and(eq(members.roomId, roomId), eq(members.userId, user.id)));
        return respond({ ok: true });
      }
      if (route === "action" && method === "POST") {
        const event = body.event;
        const payload = body.payload || {};
        if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new HttpError(400, "Некорректная команда.");
        const selected = event === "anime:select" ? await animeMedia(payload.releaseId, payload.episode) : null;
        await database.transaction(async (transaction) => {
          const [room] = await transaction.select().from(rooms).where(eq(rooms.id, roomId)).for("update");
          if (!room) throw new HttpError(404, "Комната удалена.");
          const [membership] = await transaction.select().from(members).where(and(eq(members.roomId, roomId), eq(members.userId, user.id)));
          if (!membership) throw new HttpError(403, "Нет доступа к комнате.");
          if (event === "chat:send") {
            const message = text(payload.body, "Сообщение", 1, 2000);
            const now = Date.now();
            const [allowed] = await transaction.update(users).set({ lastMessageAt: now }).where(and(eq(users.id, user.id), lt(users.lastMessageAt, now - 500))).returning({ id: users.id });
            if (!allowed) throw new HttpError(429, "Подождите немного перед следующим сообщением.");
            await transaction.insert(messages).values({ id: randomUUID(), roomId, userId: user.id, body: message, created: now });
            return;
          }
          if (event === "room:control") {
            if (room.owner !== user.id) throw new HttpError(403, "Только владелец может передать управление.");
            const targetId = text(payload.userId, "Участник", 1, 100);
            const [target] = await transaction.select().from(members).innerJoin(users, eq(members.userId, users.id)).where(and(
              eq(members.roomId, roomId), eq(members.userId, targetId), gt(members.lastSeen, Date.now() - 45000), eq(users.banned, false),
            ));
            if (!target) throw new HttpError(400, "Участник не в сети.");
            await transaction.update(rooms).set({ controller: targetId }).where(eq(rooms.id, roomId));
            return;
          }
          if (event === "room:ping") return;
          if (room.controller !== user.id) throw new HttpError(403, "Управление доступно ведущему комнаты.");
          const state = { ...room.state, updatedAt: Math.max(Date.now(), room.state.updatedAt + 1) };
          if (event === "media:select" || event === "anime:select") {
            const media = validateMedia(selected || payload.media);
            state.media = selected ? { ...media, provider: "anilibria", releaseId: selected.releaseId } : media;
            state.mediaVersion = (room.state.mediaVersion || 0) + 1;
            state.position = 0;
            state.playing = false;
          } else if (event === "media:sync") {
            if (payload.mediaVersion !== (room.state.mediaVersion || 0)) throw new HttpError(409, "Видео уже изменилось. Повторите действие.");
            if (!room.state.media || !Number.isFinite(payload.position) || payload.position < 0 || payload.position > 604800 || typeof payload.playing !== "boolean") throw new HttpError(400, "Некорректное состояние плеера.");
            state.position = payload.position;
            state.playing = payload.playing;
          } else if (event !== "room:mode" || payload.mode !== "video") {
            throw new HttpError(400, "Эта функция недоступна в версии Netlify.");
          }
          await transaction.update(rooms).set({ state }).where(eq(rooms.id, roomId));
        });
        return respond({ ok: true, ...await snapshot(database, roomId, user.id) });
      }
    }
    if (path.startsWith("/admin/")) {
      requireAdmin(user.role);
      const page = Math.max(1, Math.min(100000, Number.parseInt(url.searchParams.get("page") || "1") || 1));
      if (path === "/admin/overview" && method === "GET") {
        const [[people], [spaces], [chat], [online]] = await Promise.all([
          database.select({ value: count() }).from(users), database.select({ value: count() }).from(rooms),
          database.select({ value: count() }).from(messages),
          database.select({ value: sql<number>`count(distinct ${members.userId})::int` }).from(members).innerJoin(users, eq(members.userId, users.id)).where(and(gt(members.lastSeen, Date.now() - 45000), eq(users.banned, false))),
        ]);
        return respond({ stats: { users: people.value, rooms: spaces.value, messages: chat.value, online: online.value }, database: "Netlify Postgres" });
      }
      if (path === "/admin/users" && method === "GET") {
        const query = (url.searchParams.get("q") || "").trim().slice(0, 80).replace(/[\\%_]/g, "\\$&");
        const list = await database.select().from(users).where(ilike(users.name, `%${query}%`)).orderBy(desc(users.created)).limit(30).offset((page - 1) * 30);
        return respond({ users: list.map((person) => publicUser(person, true)), page });
      }
      const userMatch = /^\/admin\/users\/([A-Za-z0-9_-]+)$/.exec(path);
      if (userMatch && method === "PATCH") {
        if (typeof body.banned !== "boolean") throw new HttpError(400, "Укажите статус блокировки.");
        const [updated] = await database.update(users).set({ banned: body.banned }).where(and(eq(users.id, userMatch[1]), ne(users.role, "admin"))).returning();
        if (!updated) throw new HttpError(400, "Пользователь не найден или является администратором.");
        return respond({ user: publicUser(updated, true) });
      }
      if (path === "/admin/rooms" && method === "GET") {
        const list = await database.select({ id: rooms.id, name: rooms.name, created: rooms.created, owner: users.name }).from(rooms).innerJoin(users, eq(rooms.owner, users.id)).orderBy(desc(rooms.created)).limit(30).offset((page - 1) * 30);
        return respond({ rooms: list, page });
      }
      const deleteMatch = /^\/admin\/(rooms|messages)\/([A-Za-z0-9_-]+)$/.exec(path);
      if (deleteMatch && method === "DELETE") {
        if (deleteMatch[1] === "rooms") await database.delete(rooms).where(eq(rooms.id, deleteMatch[2]));
        else await database.delete(messages).where(eq(messages.id, deleteMatch[2]));
        return respond({ ok: true });
      }
    }
    return respond({ error: "Маршрут не найден." }, 404);
  } catch (error) {
    if (error instanceof HttpError) return respond({ error: error.message }, error.status);
    if (error instanceof Error && error.name === "AuthError") return respond({ error: "Недопустимый источник запроса." }, 403);
    return respond({ error: "Сервис временно недоступен. Попробуйте ещё раз позже." }, 503);
  }
};

export const config: Config = {
  path: "/api/*",
  rateLimit: { windowLimit: 600, windowSize: 60, aggregateBy: ["ip", "domain"] },
};

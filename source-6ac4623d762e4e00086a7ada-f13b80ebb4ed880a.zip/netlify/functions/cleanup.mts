import type { Config } from "@netlify/functions";
import { lt } from "drizzle-orm";
import { getDb } from "../../db/index.js";
import { guestSessions, rateLimits } from "../../db/schema.js";

export default async () => {
  const database = getDb();
  await database.delete(guestSessions).where(lt(guestSessions.expires, Date.now()));
  await database.delete(rateLimits).where(lt(rateLimits.expires, Date.now()));
};

export const config: Config = { schedule: "0 4 * * *" };

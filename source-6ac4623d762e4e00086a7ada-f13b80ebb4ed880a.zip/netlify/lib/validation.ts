import type { Media } from "../../db/schema.js";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export function text(value: unknown, label: string, min: number, max: number): string {
  if (typeof value !== "string" || value.trim().length < min || value.trim().length > max)
    throw new HttpError(400, `${label}: от ${min} до ${max} символов.`);
  return value.trim();
}

export function validateMedia(value: unknown): Media {
  if (!value || typeof value !== "object") throw new HttpError(400, "Некорректное видео.");
  const media = value as Media;
  const title = text(media.title, "Название", 1, 200);
  if (!Number.isInteger(media.episode) || media.episode < 1 || media.episode > 10000 || !Array.isArray(media.sources) || !media.sources.length || media.sources.length > 12)
    throw new HttpError(400, "Укажите серию и от 1 до 12 источников.");
  const sources = media.sources.map((source) => {
    if (!source || typeof source !== "object") throw new HttpError(400, "Некорректный источник.");
    const url = text(source.url, "Ссылка", 1, 2048);
    if (!/^\/media\/demo-(480|720|alt)\.webm$/.test(url)) {
      let parsed: URL;
      try { parsed = new URL(url); } catch { throw new HttpError(400, "Укажите HTTPS-ссылку на видео."); }
      if (parsed.protocol !== "https:" || parsed.username || parsed.password)
        throw new HttpError(400, "Источник должен использовать HTTPS без учётных данных.");
    }
    return { url, quality: text(source.quality, "Качество", 1, 20), voice: text(source.voice, "Озвучка", 1, 40) };
  });
  return { title, episode: media.episode, sources };
}

export function avatarImage(value: string) {
  const match = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match || value.length > 90000) throw new HttpError(400, "Выберите PNG, JPEG или WebP до 65 КБ.");
  const bytes = Buffer.from(match[2], "base64");
  const valid = match[1] === "png"
    ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
    : match[1] === "jpeg"
      ? bytes.subarray(0, 3).equals(Buffer.from([255, 216, 255]))
      : bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
  if (!valid || bytes.length > 65536) throw new HttpError(400, "Некорректное изображение.");
  return { bytes, contentType: `image/${match[1]}` };
}

export function publicUser(row: {
  id: string; name: string; role: string; avatar: string; avatarVersion: number;
  theme: string; premium: boolean; preferences: unknown; email?: string | null;
  banned?: boolean; created?: number;
}, privateFields = false) {
  return {
    id: row.id, name: row.name, role: row.role,
    avatar: row.avatar.startsWith("uploads/") ? `/api/avatars/${row.id}?v=${row.avatarVersion}` : row.avatar,
    theme: row.theme, premium: row.premium, preferences: row.preferences,
    ...(privateFields ? { email: row.email, banned: row.banned, created: row.created } : {}),
  };
}

import { login, logout } from "@netlify/identity";
import { HttpError } from "./validation.js";

export function requireAdmin(role: string) {
  if (role !== "admin") throw new HttpError(403, "Нужны права администратора.");
}

export async function loginAdminAlias(body: Record<string, unknown>, configuredEmail: string | undefined) {
  const failure = () => new HttpError(401, "Не удалось войти. Проверьте email или логин и пароль или подтвердите адрес почты.");
  if (typeof body.email !== "string" || body.email.trim().toLowerCase() !== "flovifly"
    || typeof body.password !== "string" || !body.password || body.password.length > 128) throw failure();
  const email = configuredEmail?.trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new HttpError(503, "Вход по логину пока не настроен. Используйте email.");
  let account;
  try {
    account = await login(email, body.password);
  } catch { throw failure(); }
  if (account.email?.toLowerCase() !== email || !account.roles?.includes("admin")) {
    await logout();
    throw failure();
  }
}

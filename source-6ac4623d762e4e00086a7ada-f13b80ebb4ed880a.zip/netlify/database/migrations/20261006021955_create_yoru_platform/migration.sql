CREATE TABLE "yoru_favorites" (
	"user_id" text,
	"anime_id" text,
	"anime" jsonb NOT NULL,
	CONSTRAINT "yoru_favorites_pkey" PRIMARY KEY("user_id","anime_id")
);
--> statement-breakpoint
CREATE TABLE "yoru_guest_sessions" (
	"token_hash" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"expires" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "yoru_members" (
	"room_id" text,
	"user_id" text,
	"last_seen" bigint NOT NULL,
	CONSTRAINT "yoru_members_pkey" PRIMARY KEY("room_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "yoru_messages" (
	"id" text PRIMARY KEY,
	"room_id" text NOT NULL,
	"user_id" text NOT NULL,
	"body" text NOT NULL,
	"created" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "yoru_rate_limits" (
	"key" text PRIMARY KEY,
	"hits" integer DEFAULT 1 NOT NULL,
	"expires" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "yoru_rooms" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"owner" text NOT NULL,
	"controller" text NOT NULL,
	"state" jsonb NOT NULL,
	"created" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "yoru_users" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"email" text,
	"role" text DEFAULT 'user' NOT NULL,
	"avatar" text DEFAULT 'moon' NOT NULL,
	"avatar_version" bigint DEFAULT 0 NOT NULL,
	"theme" text DEFAULT 'midnight' NOT NULL,
	"premium" boolean DEFAULT false NOT NULL,
	"banned" boolean DEFAULT false NOT NULL,
	"preferences" jsonb DEFAULT '{}' NOT NULL,
	"last_message_at" bigint DEFAULT 0 NOT NULL,
	"created" bigint NOT NULL
);
--> statement-breakpoint
CREATE INDEX "yoru_sessions_expires_idx" ON "yoru_guest_sessions" ("expires");--> statement-breakpoint
CREATE INDEX "yoru_members_user_idx" ON "yoru_members" ("user_id");--> statement-breakpoint
CREATE INDEX "yoru_messages_room_created_idx" ON "yoru_messages" ("room_id","created");--> statement-breakpoint
CREATE INDEX "yoru_limits_expires_idx" ON "yoru_rate_limits" ("expires");--> statement-breakpoint
CREATE INDEX "yoru_rooms_owner_idx" ON "yoru_rooms" ("owner");--> statement-breakpoint
ALTER TABLE "yoru_favorites" ADD CONSTRAINT "yoru_favorites_user_id_yoru_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "yoru_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_guest_sessions" ADD CONSTRAINT "yoru_guest_sessions_user_id_yoru_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "yoru_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_members" ADD CONSTRAINT "yoru_members_room_id_yoru_rooms_id_fkey" FOREIGN KEY ("room_id") REFERENCES "yoru_rooms"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_members" ADD CONSTRAINT "yoru_members_user_id_yoru_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "yoru_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_messages" ADD CONSTRAINT "yoru_messages_room_id_yoru_rooms_id_fkey" FOREIGN KEY ("room_id") REFERENCES "yoru_rooms"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_messages" ADD CONSTRAINT "yoru_messages_user_id_yoru_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "yoru_users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "yoru_rooms" ADD CONSTRAINT "yoru_rooms_owner_yoru_users_id_fkey" FOREIGN KEY ("owner") REFERENCES "yoru_users"("id");--> statement-breakpoint
ALTER TABLE "yoru_rooms" ADD CONSTRAINT "yoru_rooms_controller_yoru_users_id_fkey" FOREIGN KEY ("controller") REFERENCES "yoru_users"("id");